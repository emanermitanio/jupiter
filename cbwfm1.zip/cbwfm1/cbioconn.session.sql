SELECT
    PROCESS,
    COUNT(*) AS Volume,
    SUM(CASE WHEN Priority = 'Rush' AND "ASSIGNED_SID" IS NOT NULL THEN 1 ELSE 0 END) AS ct_Rush_Assigned,
    SUM(CASE WHEN Priority = 'Rush' AND "ASSIGNED_SID" IS NULL THEN 1 ELSE 0 END) AS ct_Rush_Unassigned,
    SUM(CASE WHEN Priority = 'Regular' AND "ASSIGNED_SID" IS NOT NULL THEN 1 ELSE 0 END) AS ct_Reg_Assigned,
    SUM(CASE WHEN Priority = 'Regular' AND "ASSIGNED_SID" IS NULL THEN 1 ELSE 0 END) AS ct_Reg_Unassigned
FROM
    TBL_PIPELINE
GROUP BY
    PROCESS;
