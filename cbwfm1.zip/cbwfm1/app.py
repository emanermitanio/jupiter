from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response
from datetime import datetime
import sqlite3
import pytz
import os
import csv
import pdfkit
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'pipeupload')

app.secret_key = 'supersecretkey'

def get_db():
    conn = sqlite3.connect('cbio.db')
    conn.row_factory = sqlite3.Row 
    return conn

def get_ist_time():
    # Define IST timezone
    ist = pytz.timezone('Asia/Kolkata')
    
    # Get the current time in IST
    now_ist = datetime.now(ist)
    
    # Format the date and date with time
    dtnow = now_ist.strftime('%Y-%m-%d')
    tsnow = now_ist.strftime('%Y-%m-%d %H:%M:%S')
    tsnow_12hr = now_ist.strftime('%Y-%m-%d %I:%M:%S %p')
    
    return dtnow, tsnow, tsnow_12hr

@app.route('/')
def index():
    session.clear()
    return render_template('index.html')

@app.route('/home')
def home():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    session['sess_cat'] = 'SHOWALL'

    if usersid:
        # Pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = 20  # Number of items per page

        # Get total number of cases
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM TBL_PIPELINE WHERE ASSIGNED_SID = ? AND REVIEW_STATUS = 'LOCKED'", (usersid,))
        total = cursor.fetchone()[0]

        # Get assigned cases with limit and offset
        offset = (page - 1) * per_page
        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE ASSIGNED_SID = ? AND REVIEW_STATUS = 'LOCKED' LIMIT ? OFFSET ?", (usersid, per_page, offset))
        d_assigned = cursor.fetchall()
        cursor.close()
        conn.close()

        total_pages = (total + per_page - 1) // per_page  # Calculate total pages

        return render_template('home.html', usersid=usersid, username=username, useraccess=useraccess, d_assigned=d_assigned, page=page, total_pages=total_pages)
    else:
        return redirect('/')
    
@app.route('/changepassword')
def changepassword():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    if usersid:
        return render_template('changepassword.html', usersid=usersid, username=username, useraccess=useraccess)
    else:
        return redirect('/')

@app.route('/userchangepassword', methods=['POST'])   
def userchangepassword():
    usersid = session.get('sess_usersid')
    userpassword = request.form['userpassword']
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_USER SET USERPASSWORD = ? WHERE USERSID = ?", (userpassword,usersid))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect('/')


@app.route('/userlogin', methods=['POST'])
def userlogin():
    u_sid = request.form['usersid']
    u_pass = request.form['userpassword']

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT USERSID, USERNAME, ACCESS_LEVEL FROM TBL_USER WHERE USERSID = ? AND USERPASSWORD = ?", (u_sid, u_pass))
    userdata = cursor.fetchone()
    
    if userdata:
        session['sess_usersid'] = userdata[0]
        session['sess_username'] = userdata[1]
        session['sess_useraccess'] = userdata[2]
        cursor.close()
        db.close()
        return redirect(url_for('home'))
    else:
        flash('Invalid credentials. Please try again.', 'error')
        cursor.close()
        db.close()
        return redirect(url_for('index'))


# MANAGER PAGE
@app.route('/manager')
def manager():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')
    dtnow, tsnow, tsnow_12hr = get_ist_time()

    v_process = request.args.get('v_process', '')
    v_ctr = request.args.get('v_ctr', '')

    pipe_workgroup = session.get('sess_pipe_workgroup')
    pipe_start = session.get('sess_pipe_start')
    pipe_end = session.get('sess_pipe_end')

    print(pipe_workgroup)
    print(pipe_start)
    print(pipe_end)

    if useraccess > 1:
        conn = get_db()
        cursor = conn.cursor()

        if v_ctr == 'RUSHASSIGNED':
            q = """
                SELECT * FROM TBL_PIPELINE 
                WHERE PROCESS = ? 
                AND PRIORITY = 'Rush' 
                AND ASSIGNED_SID IS NOT NULL 
                AND WORKGROUP = ? 
                AND REQUEST_RECEIVED_DATE BETWEEN ? AND ?
            """
            cursor.execute(q, (v_process, pipe_workgroup, pipe_start, pipe_end))

        elif v_ctr == 'RUSHUNASSIGNED':
            q = """
                SELECT * FROM TBL_PIPELINE 
                WHERE PROCESS = ? 
                AND PRIORITY = 'Rush' 
                AND ASSIGNED_SID IS NULL 
                AND WORKGROUP = ? 
                AND REQUEST_RECEIVED_DATE BETWEEN ? AND ?
            """
            cursor.execute(q, (v_process, pipe_workgroup, pipe_start, pipe_end))
        elif v_ctr == 'REGULARASSIGNED':
            q = """
                SELECT * FROM TBL_PIPELINE 
                WHERE PROCESS = ? 
                AND PRIORITY = 'Regular' 
                AND ASSIGNED_SID IS NOT NULL 
                AND WORKGROUP = ? 
                AND REQUEST_RECEIVED_DATE BETWEEN ? AND ?
            """
            cursor.execute(q, (v_process, pipe_workgroup, pipe_start, pipe_end))
        elif v_ctr == 'REGULARUNASSIGNED':
                q = """
                SELECT * FROM TBL_PIPELINE 
                WHERE PROCESS = ? 
                AND PRIORITY = 'Regular' 
                AND ASSIGNED_SID IS NULL 
                AND WORKGROUP = ? 
                AND REQUEST_RECEIVED_DATE BETWEEN ? AND ?
            """
                cursor.execute(q, (v_process, pipe_workgroup, pipe_start, pipe_end))
        elif v_ctr == 'VOLUME':
                q = """
                SELECT * FROM TBL_PIPELINE 
                WHERE PROCESS = ? 
                AND WORKGROUP = ? 
                AND REQUEST_RECEIVED_DATE BETWEEN ? AND ?
            """
                cursor.execute(q, (v_process, pipe_workgroup, pipe_start, pipe_end))
        else:
            cursor.execute("SELECT * FROM TBL_PIPELINE WHERE WORKGROUP = ? AND REQUEST_RECEIVED_DATE BETWEEN ? AND ?",(pipe_workgroup,pipe_start,pipe_end))
         
        d_queue = cursor.fetchall()

        # Get all users
        cursor.execute("SELECT USERSID, USERNAME, WORKGROUP FROM TBL_USER ORDER BY USERNAME")
        users = cursor.fetchall()

        #Pipeline Grid
        q = '''
            SELECT
            PROCESS,
            COUNT(*) AS Volume,
            SUM(CASE WHEN Priority = 'Rush' AND "ASSIGNED_SID" IS NOT NULL THEN 1 ELSE 0 END) AS ct_Rush_Assigned,
            SUM(CASE WHEN Priority = 'Rush' AND "ASSIGNED_SID" IS NULL THEN 1 ELSE 0 END) AS ct_Rush_Unassigned,
            SUM(CASE WHEN Priority = 'Regular' AND "ASSIGNED_SID" IS NOT NULL THEN 1 ELSE 0 END) AS ct_Reg_Assigned,
            SUM(CASE WHEN Priority = 'Regular' AND "ASSIGNED_SID" IS NULL THEN 1 ELSE 0 END) AS ct_Reg_Unassigned
        FROM
            TBL_PIPELINE
        WHERE WORKGROUP = ? AND REQUEST_RECEIVED_DATE BETWEEN ? AND ?
        GROUP BY
            PROCESS;
    '''
        cursor.execute(q,(pipe_workgroup,pipe_start,pipe_end))
        pipeline = cursor.fetchall()
        cursor.close()
        conn.close()

        return render_template('manager.html', usersid=usersid, username=username, d_queue=d_queue, users=users, 
                               tsnow_12hr=tsnow_12hr,pipeline=pipeline,dtnow=dtnow,
                               pipe_start=pipe_start,pipe_end=pipe_end,pipe_workgroup=pipe_workgroup)
    else:
        return redirect('/home')

@app.route('/viewpipeline')
def viewpipeline():
    v_process = request.args.get('v_process')
    v_ctr = request.args.get('v_ctr')
    return redirect(url_for('manager',v_process=v_process, v_ctr=v_ctr))

@app.route('/filterPipeline', methods=['POST'])
def filterPipeline():
    pipe_workgroup = request.form.get('pipe_workgroup')
    pipe_start = request.form['pipe_start']
    pipe_end = request.form['pipe_end']

    session['sess_pipe_workgroup'] = pipe_workgroup
    session['sess_pipe_start'] = pipe_start
    session['sess_pipe_end'] = pipe_end

    return redirect(url_for('manager',pipe_workgroup=pipe_workgroup, pipe_start=pipe_start,pipe_end=pipe_end))


@app.route('/assign_case', methods=['POST'])
def assign_case():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    a_sid = request.form.get('assignedsid')
    assignedsid = a_sid[:7]
    assignedname = a_sid[7:]
    pipeid = request.form['pipeid']
    priority = request.form.get('priority')
    dtnow, tsnow, tsnow_12hr = get_ist_time()

    if useraccess > 1:

        conn = get_db()
        cursor = conn.cursor()


        #get all users
        cursor.execute("SELECT USERSID, USERNAME, WORKGROUP FROM TBL_USER ORDER BY USERNAME")
        users = cursor.fetchall()

        cursor.execute("UPDATE TBL_PIPELINE SET ASSIGNED_SID = ?, ASSIGNED_REVIEWER = ?, PRIORITY = ?, REVIEW_STATUS = 'LOCKED', ASSIGNED_DATE = ? WHERE PIPE_ID = ?", (assignedsid,assignedname,priority,tsnow,pipeid))
        conn.commit()       

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE REVIEW_STATUS = 'OPEN'")
        d_unassigned = cursor.fetchall()

        cursor.close()
        conn.close()

        flash('Case assignment complete.', 'success')
        

        return redirect(request.referrer)
    else:
        return redirect('/home')
    
@app.route('/casedetails')
def casedetails():

    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')
    session['process'] = request.args.get('process')

    pipe_id = request.args.get('pipe_id')

    if usersid:

        #get assigned cases

        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID=?", (pipe_id,))
        casedetails = cursor.fetchall()

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID=?", (pipe_id,))
        getdetails = cursor.fetchone()

        wgroup = getdetails['WORKGROUP']
        pkgtype = getdetails['PACKAGE_TYPE']
        loc = getdetails['LOCATION']

        #check if there is available checklist

        cursor.execute("SELECT COUNT(*) FROM TBL_CHECKLIST WHERE WORKGROUP = ? AND PACKAGE_TYPE = ? AND LOCATION = ?", (wgroup,pkgtype,loc))
        chk_avail = cursor.fetchone()[0]

        #get logged checklist for this pipeid
        qry = '''
       SELECT 
    ta.PIPE_ID, 
    ta.REVIEW_TYPE, 
    ta.REVIEW_DATE, 
    ta.REVIEWER_SID, 
    tu.USERNAME AS REVIEWER_NM,
    CASE 
        WHEN COUNT(*) = 0 THEN 0
        ELSE ROUND(CAST(SUM(CASE WHEN ta.REVIEWER_ANSWER IS NOT NULL AND ta.REVIEWER_ANSWER <> '' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) * 100, 2)
    END AS COMPLETION_RATE
FROM TBL_AUDIT ta
JOIN TBL_USER tu ON ta.REVIEWER_SID = tu.USERSID
WHERE ta.PIPE_ID = ?
GROUP BY ta.PIPE_ID, ta.REVIEW_TYPE, ta.REVIEW_DATE, ta.REVIEWER_SID;
        '''
        cursor.execute(qry,(pipe_id,))
        audits = cursor.fetchall()

        

        cursor.close()
        conn.close()

        return render_template('casedetails.html', usersid=usersid, username=username, useraccess=useraccess,
                               casedetails=casedetails,chk_avail=chk_avail,audits=audits)
    else:
        return redirect('/')

@app.route('/updateworkflow', methods=['POST'])
def updateworkflow():
    pipe_id = request.form['pipe_id']
    process = request.form.get('process')
    reason = request.form.get('reason')

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET PROCESS = ?, PENDING_REJECT_REASON = ?, ASSIGNED_SID = NULL, ASSIGNED_REVIEWER = NULL WHERE PIPE_ID =?", (process,reason,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect('/home')

@app.route('/clonerequest', methods=['POST'])
def clonerequest():
    pipe_id = request.form['pipe_id']
    ecid = request.form['ecid']
   
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID = ?", (pipe_id,))
    record = cursor.fetchone()

    if record:
        columns = [desc[0] for desc in cursor.description if desc[0] != 'PIPE_ID']
        values = [record[i] for i in range(len(record)) if cursor.description[i][0] != 'PIPE_ID']
        
        # Update the ECID value in the list
        if 'ECID' in columns:
            ecid_index = columns.index('ECID')
            values[ecid_index] = ecid

        placeholders = ', '.join(['?'] * len(columns))
        columns = ', '.join(columns)
        cursor.execute(f"INSERT INTO TBL_PIPELINE ({columns}) VALUES ({placeholders})", values)
        conn.commit()

    cursor.close()
    conn.close()

    return redirect('/home')

@app.route('/updateEntityName', methods=['POST'])
def updateEntityName():
    pipe_id = request.form['pipe_id']
    entityname = request.form['entityname']
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET ENTITY_NAME = ? WHERE PIPE_ID =?", (entityname,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updateEntityCount', methods=['POST'])
def updateEntityCount():
    pipe_id = request.form['pipe_id']
    entitycount = request.form['entitycount']
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET NO_OF_ENTITIES = ? WHERE PIPE_ID =?", (entitycount,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updatePackageType', methods=['POST'])
def updatePackageType():
    pipe_id = request.form['pipe_id']
    packagetype = request.form.get('packagetype')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET PACKAGE_TYPE = ? WHERE PIPE_ID =?", (packagetype,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updateLocation', methods=['POST'])
def updateLocation():
    pipe_id = request.form['pipe_id']
    location = request.form.get('location')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET LOCATION = ? WHERE PIPE_ID =?", (location,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updateECID', methods=['POST'])
def updateECID():
    pipe_id = request.form['pipe_id']
    ecid = request.form['ecid']
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET ECID = ? WHERE PIPE_ID =?", (ecid,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/createreview', methods=['POST'])
def createreview():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')
    dtnow, tsnow, tsnow_12hr = get_ist_time()

    pipe_id = request.form['pipe_id']
    reviewtype = request.form['reviewtype']
    wgroup = request.form['wgroup']
    packagetype = request.form['packagetype']
    location = request.form['location']

    session['sess_pipe_id'] = pipe_id

    conn = get_db()
    cursor = conn.cursor()

    if reviewtype == 'MAKER':
        qry = '''
            INSERT INTO TBL_AUDIT (
                REVIEW_TYPE,
                PIPE_ID,
                CHKPT_ID,
                REVIEW_DATE,
                REVIEWER_SID
            )
            SELECT 
                ? AS REVIEW_TYPE,
                ? AS PIPE_ID,
                CHKPT_ID,
                ? AS REVIEW_DATE,
                ? AS REVIEWER_SID
            FROM TBL_CHECKLIST
            WHERE WORKGROUP = ? AND PACKAGE_TYPE = ? AND LOCATION = ? AND ACTIVE = 1;
            '''
        cursor.execute(qry,(reviewtype,pipe_id,dtnow,usersid,wgroup,packagetype,location))
        conn.commit()
    else:
        qry = '''
            INSERT INTO TBL_AUDIT (
                REVIEW_TYPE,
                PIPE_ID,
                CHKPT_ID,
                REVIEW_DATE,
                REVIEWER_SID
            )
            SELECT 
                ? AS REVIEW_TYPE,
                ? AS PIPE_ID,
                CHKPT_ID,
                ? AS REVIEW_DATE,
                ? AS REVIEWER_SID
            FROM TBL_AUDIT
            WHERE PIPE_ID = ? AND REVIEW_TYPE = 'MAKER';
            '''
        cursor.execute(qry,('CHECKER',pipe_id,dtnow,usersid,pipe_id))
        conn.commit()


    cursor.close
    conn.close

    return redirect(request.referrer)

@app.route('/selectcategory')
def selectcategory():
    c = request.args.get('cat')
    session['sess_cat'] = c
    return redirect(request.referrer)

@app.route('/addNewCheckpoint', methods=['POST'])
def addNewCheckpoint():
    usersid = session.get('sess_usersid')
    newchkpt = request.form['newchkpt']
    category = request.form['category']
    pipe_id = request.form['pipe_id']
    reviewtype = request.form['reviewtype']

    conn = get_db()
    cursor = conn.cursor()

    #get myreviewdate
    cursor.execute("SELECT MAX(REVIEW_DATE) FROM TBL_AUDIT WHERE PIPE_ID = ? AND REVIEW_TYPE = ? AND REVIEWER_SID = ?",(pipe_id,reviewtype,usersid))
    revdt = cursor.fetchone()[0]

    #get max chkptid in checklist
    cursor.execute("SELECT MAX(CHKPT_ID) FROM TBL_CHECKLIST")
    maxid = cursor.fetchone()[0]
    chkptid = maxid + 1
    q = '''
        INSERT INTO TBL_CHECKLIST (
        CHKPT_ID,
        CATEGORY,
        CHECKPOINT,
        ACTIVE,
        CREATE_TYPE,
        CREATE_SID
    )
    VALUES (?,?,?,0,'Manual',?);   
    '''
    cursor.execute(q,(chkptid,category,newchkpt,usersid))
    conn.commit()

    #add new checkpoint
    q = '''
        INSERT INTO TBL_AUDIT (
        REVIEW_TYPE,
        PIPE_ID,
        CHKPT_ID,
        REVIEW_DATE,
        REVIEWER_SID,
        REVIEWER_ANSWER
        )
        VALUES (?,?,?,?,?,?);
        '''
    cursor.execute(q,(reviewtype,pipe_id,chkptid,revdt,usersid,'Additional Requirement'))
    conn.commit()
    cursor.close()
    conn.close()
    

    return redirect(request.referrer)

@app.route('/checklist')
def checklist():

    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')
    
    reviewtype = request.args.get('reviewtype')
    process = session.get('sess_process')
    category = session.get('sess_cat')

    pipe_id = request.args.get('pipe_id')
    
    if pipe_id:
        pipe_id = request.args.get('pipe_id')
    else:
        pipe_id = session.get('sess_pipe_id')

    


    if usersid:

        #get created checklist for this pipe_id

        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID=?", (pipe_id,))
        casedetails = cursor.fetchall()

        qry = '''
        SELECT 
            m.PIPE_ID,
            m.REVIEW_DATE AS MAKER_DT,
            m.REVIEWER_SID AS MAKER_SID, 
            mu.USERNAME AS MAKER_NM,
            COALESCE(c.REVIEW_DATE, NULL) AS CHECKER_DT, 
            COALESCE(c.REVIEWER_SID, NULL) AS CHECKER_SID, 
            COALESCE(cu.USERNAME, NULL) AS CHECKER_NM
        FROM 
            TBL_AUDIT m
        LEFT JOIN 
            TBL_AUDIT c ON m.PIPE_ID = c.PIPE_ID AND c.REVIEW_TYPE = 'CHECKER' AND m.REVIEW_DATE = c.REVIEW_DATE
        LEFT JOIN 
            TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
        LEFT JOIN 
            TBL_USER cu ON c.REVIEWER_SID = cu.USERSID
        WHERE 
            m.REVIEW_TYPE = 'MAKER' AND m.PIPE_ID = ?
        LIMIT 1;
        '''
        cursor.execute(qry,pipe_id)
        mc = cursor.fetchone()
        maker_dt = mc[1]
        maker_nm = mc[3]
        checker_dt = mc[4]
        checker_nm = mc[6]

        
        


        #get questions
        if reviewtype == 'MAKER':
            if category =='SHOWALL':
                q = '''
                    SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS MAKER_DT,
                    tblc.CATEGORY,
                    tblc.CHKPT_ID, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS MAKER_SID,
                    tblu_rev.USERNAME AS MAKER_NM,
                    tbla.REVIEWER_ANSWER AS MAKER_ANS,
                    tbla.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                    m.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS CHECKER_DT,
                    mu.USERNAME AS CHECKER_NM,
                    m.REVIEWER_ANSWER AS CHECKER_ANS,
                    m.REVIEWER_COMMENTS AS CHECKER_COMMENTS,
                    tblc.ANSWER_TYPE
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID, REMEDIATED
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'CHECKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'MAKER' 
                    AND tbla.PIPE_ID = ?;
                '''
                cursor.execute(q,(pipe_id,))
                questionset = cursor.fetchall()
            elif category =='PENDING ITEMS':
                q = '''
                    SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS MAKER_DT,
                    tblc.CATEGORY,
                    tblc.CHKPT_ID, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS MAKER_SID,
                    tblu_rev.USERNAME AS MAKER_NM,
                    tbla.REVIEWER_ANSWER AS MAKER_ANS,
                    tbla.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                    m.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS CHECKER_DT,
                    mu.USERNAME AS CHECKER_NM,
                    m.REVIEWER_ANSWER AS CHECKER_ANS,
                    m.REVIEWER_COMMENTS AS CHECER_COMMENTS,
                    tblc.ANSWER_TYPE
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID, REMEDIATED
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'CHECKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'MAKER' AND tbla.PIPE_ID = ? AND tbla.REVIEWER_ANSWER IS NULL;

                '''
                cursor.execute(q,(pipe_id,))
                questionset = cursor.fetchall()
            elif category =='FAILED ITEMS':
                q = '''
                     SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS MAKER_DT,
                    tblc.CATEGORY,
                    tblc.CHKPT_ID, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS MAKER_SID,
                    tblu_rev.USERNAME AS MAKER_NM,
                    tbla.REVIEWER_ANSWER AS MAKER_ANS,
                    tbla.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                    m.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS CHECKER_DT,
                    mu.USERNAME AS CHECKER_NM,
                    m.REVIEWER_ANSWER AS CHECKER_ANS,
                    m.REVIEWER_COMMENTS AS CHECER_COMMENTS,
                    tblc.ANSWER_TYPE
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID, RESOLUTION_STATUS, REMEDIATED
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'CHECKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'MAKER' AND tbla.PIPE_ID = ? AND (m.RESOLUTION_STATUS = 'FAIL' OR m.RESOLUTION_STATUS = 'ERROR STAND');
                '''
                cursor.execute(q,(pipe_id,))
                questionset = cursor.fetchall()
            else:
                q = '''
                    SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS MAKER_DT,
                    tblc.CATEGORY,
                    tblc.CHKPT_ID, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS MAKER_SID,
                    tblu_rev.USERNAME AS MAKER_NM,
                    tbla.REVIEWER_ANSWER AS MAKER_ANS,
                    tbla.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                    m.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS CHECKER_DT,
                    mu.USERNAME AS CHECKER_NM,
                    m.REVIEWER_ANSWER AS CHECKER_ANS,
                    m.REVIEWER_COMMENTS AS CHECKER_COMMENTS,
                    tblc.ANSWER_TYPE
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID, REMEDIATED
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'CHECKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'MAKER' 
                    AND tbla.PIPE_ID = ? AND tblc.CATEGORY = ?;
                '''
                cursor.execute(q,(pipe_id,category))
                questionset = cursor.fetchall()
        else: #if Checker
            if category =='SHOWALL':
                q = '''
                    SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS CHECKER_DT,
                    tblc.CATEGORY, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS CHECKER_SID,
                    tblu_rev.USERNAME AS CHECKER_NM,
                    tbla.REVIEWER_ANSWER AS CHECKER_ANS,
                    tbla.REVIEWER_COMMENTS AS CHECKER_COMMENTS,
                    tbla.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS MAKER_DT,
                    mu.USERNAME AS MAKER_NM,
                    m.REVIEWER_ANSWER AS MAKER_ANS,
                    m.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                    tblc.ANSWER_TYPE
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'MAKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'CHECKER' 
                    AND tbla.PIPE_ID = ?;

                '''
                cursor.execute(q,(pipe_id,))
                questionset = cursor.fetchall()
            elif category =='PENDING ITEMS':
                q = '''
                    SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS CHECKER_DT,
                    tblc.CATEGORY, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS CHECKER_SID,
                    tblu_rev.USERNAME AS CHECKER_NM,
                    tbla.REVIEWER_ANSWER AS CHECKER_ANS,
                    tbla.REVIEWER_COMMENTS AS CHECKER_COMMENTS,
                    tbla.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS MAKER_DT,
                    mu.USERNAME AS MAKER_NM,
                    m.REVIEWER_ANSWER AS MAKER_ANS,
                    m.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                    tblc.ANSWER_TYPE
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'MAKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'CHECKER' AND tbla.PIPE_ID = ? AND tbla.REVIEWER_ANSWER IS NULL
                '''
                cursor.execute(q,(pipe_id,))
                questionset = cursor.fetchall()

            elif category =='FAILED ITEMS':
                q = '''
                    SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS CHECKER_DT,
                    tblc.CATEGORY, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS CHECKER_SID,
                    tblu_rev.USERNAME AS CHECKER_NM,
                    tbla.REVIEWER_ANSWER AS CHECKER_ANS,
                    tbla.REVIEWER_COMMENTS AS CHECKER_COMMENTS,
                    tbla.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS MAKER_DT,
                    mu.USERNAME AS MAKER_NM,
                    m.REVIEWER_ANSWER AS MAKER_ANS,
                    m.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                    tblc.ANSWER_TYPE
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'MAKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'CHECKER' AND tbla.PIPE_ID = ? AND tbla.REVIEWER_ANSWER = 'FAIL'
                '''
                cursor.execute(q,(pipe_id,))
                questionset = cursor.fetchall()
            else:
                q = '''
                    SELECT 
                        tbla.ID,
                        tbla.REVIEW_TYPE,
                        tbla.PIPE_ID,
                        tbla.REVIEW_DATE AS CHECKER_DT,
                        tblc.CATEGORY, 
                        tblc.CHECKPOINT,
                        tbla.REVIEWER_SID AS CHECKER_SID,
                        tblu_rev.USERNAME AS CHECKER_NM,
                        tbla.REVIEWER_ANSWER AS CHECKER_ANS,
                        tbla.REVIEWER_COMMENTS AS CHECKER_COMMENTS,
                        tbla.REMEDIATED,
                        tblu_disp.USERNAME AS DISPUTE_NM, 
                        tblu_reso.USERNAME AS RESOLVED_NM,
                        m.REVIEW_DATE AS MAKER_DT,
                        mu.USERNAME AS MAKER_NM,
                        m.REVIEWER_ANSWER AS MAKER_ANS,
                        m.REVIEWER_COMMENTS AS MAKER_COMMENTS,
                        tblc.ANSWER_TYPE
                    FROM 
                        TBL_AUDIT tbla
                    JOIN 
                        TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                    LEFT JOIN 
                        TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                    LEFT JOIN 
                        TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                    JOIN 
                        TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                    LEFT JOIN 
                        (SELECT 
                            REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID
                        FROM 
                            TBL_AUDIT 
                        WHERE 
                            REVIEW_TYPE = 'MAKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                    LEFT JOIN 
                        TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                    WHERE 
                        tbla.REVIEW_TYPE = 'CHECKER' 
                        AND tbla.PIPE_ID = ? AND tblc.CATEGORY = ?;

                '''
                cursor.execute(q,(pipe_id,category))
                questionset = cursor.fetchall()       
        

        #get categories
        q = '''
        SELECT 
            tblc.CATEGORY,
            COUNT(CASE WHEN tbla.REVIEWER_ANSWER IS NULL THEN 1 END) AS PENDING
        FROM 
            TBL_AUDIT tbla
        JOIN 
            TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
        WHERE 
            tbla.REVIEW_TYPE = ? 
            AND tbla.PIPE_ID = ?
        GROUP BY 
            tblc.CATEGORY
        '''
        cursor.execute(q,(reviewtype,pipe_id))
        categories = cursor.fetchall()

        cursor.close()
        conn.close()


        return render_template('checklist.html', usersid=usersid, username=username, useraccess=useraccess,
                               casedetails=casedetails,questionset=questionset,categories=categories,
                               maker_dt=maker_dt,maker_nm=maker_nm,checker_dt=checker_dt,checker_nm=checker_nm,
                               category=category,reviewtype=reviewtype,pipe_id=pipe_id,process=process)
    else:
        return redirect('/')

@app.route('/updateReviewerAnswer', methods=['POST'])
def updateReviewerAnswer():
    id = request.form['id']
    answer = request.form.get('dropdownOption') or request.form.get('radioOption') or request.form.get('textInput')
        
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE TBL_AUDIT SET REVIEWER_ANSWER = ? WHERE ID = ?', (answer, id))
    conn.commit()

    if answer == 'FAIL':
        cursor.execute('UPDATE TBL_AUDIT SET RESOLUTION_STATUS = ? WHERE ID = ?', (answer, id))
        conn.commit()
    else:
        cursor.execute('UPDATE TBL_AUDIT SET RESOLUTION_STATUS = NULL WHERE ID = ?', (id,))
        conn.commit()

    cursor.close()
    conn.close()
    
    return redirect(request.referrer)

@app.route('/saveReviewerComments', methods=['POST'])
def saveReviewerComments():
    qid = request.form['qid']
    revcomments = request.form['revcomments']

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE TBL_AUDIT SET REVIEWER_COMMENTS = ? WHERE ID = ?',(revcomments,qid))
    conn.commit()

    cursor.close()
    conn.close()
    return redirect(request.referrer)

@app.route('/saveRemediate', methods=['POST'])
def saveRemediate():
    qid = request.form['qid']
    remediate = request.form.get('remediate')

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE TBL_AUDIT SET REMEDIATED = ? WHERE ID = ?',(remediate,qid))
    conn.commit()

    cursor.close()
    conn.close()
    return redirect(request.referrer)

@app.route('/resetanswer')
def resetanswer():
    id = request.args.get('id')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_AUDIT SET REVIEWER_ANSWER = Null WHERE ID = ?", (id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(request.referrer)

#pipeline upload
@app.route('/uploadPipeline', methods=['POST'])
def upload_pipeline():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        process_csv(file_path)
        flash('File successfully uploaded and data inserted')
        return redirect(url_for('viewpipeline'))
    return redirect(request.url)

def convert_empty_to_none(row):
    return {key: (value if value != '' else None) for key, value in row.items()}

def process_csv(file_path):
    conn = get_db()
    cursor = conn.cursor()
    try:
        with open(file_path, newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                row = convert_empty_to_none(row)
                cursor.execute("""
                    INSERT INTO TBL_PIPELINE (
                        LOB, DEPARTMENT, WORKGROUP, PROCESS, 
                        REQUEST_RECEIVED_YEAR, REQUEST_RECEIVED_MONTH, REQUEST_RECEIVED_DATE, 
                        TARGET_SLA_DATE, IOS_MANAGER, IOS_NAME, PACKAGE_TYPE, CROSS_BORDER, 
                        ENTITY_NAME, IR_NUMBER, OR_NUMBER, DDA_PLI_NUMBER, ECID, DOC_SOLUTION_CAPTURE, 
                        PRIORITY, LOCATION, PROCESS_LOCATION, NO_OF_ENTITIES, PLI_ASSIGNED, 
                        ASSIGNED_SID, ASSIGNED_REVIEWER, REVIEW_DATE, REVIEW_STATUS, 
                        PENDING_REJECT_REASON, REVIEWER_COMMENTS, ASSIGNED_DATE, PARENT_ENTITY
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        row['LOB'], row['DEPARTMENT'], row['WORKGROUP'], row['PROCESS'], 
                        row['REQUEST_RECEIVED_YEAR'], row['REQUEST_RECEIVED_MONTH'], row['REQUEST_RECEIVED_DATE'], 
                        row['TARGET_SLA_DATE'], row['IOS_MANAGER'], row['IOS_NAME'], row['PACKAGE_TYPE'], row['CROSS_BORDER'], 
                        row['ENTITY_NAME'], row['IR_NUMBER'], row['OR_NUMBER'], row['DDA_PLI_NUMBER'], row['ECID'], row['DOC_SOLUTION_CAPTURE'], 
                        row['PRIORITY'], row['LOCATION'], row['PROCESS_LOCATION'], row['NO_OF_ENTITIES'], row['PLI_ASSIGNED'], 
                        row['ASSIGNED_SID'], row['ASSIGNED_REVIEWER'], row['REVIEW_DATE'], row['REVIEW_STATUS'], 
                        row['PENDING_REJECT_REASON'], row['REVIEWER_COMMENTS'], row['ASSIGNED_DATE'], row['PARENT_ENTITY']
                    )
                )
        conn.commit()
    except Exception as e:
        print(f"Error processing CSV file: {e}")
    finally:
        conn.close()
        os.remove(file_path)


@app.route('/generate-pdf')
def generate_pdf():
    # Create a PDF file in memory
    from io import BytesIO
    buffer = BytesIO()
    
    # Create a canvas object
    c = canvas.Canvas(buffer, pagesize=letter)
    
    # Draw text on the PDF
    c.drawString(100, 750, "Hello, world!")
    
    # Save the PDF
    c.save()
    
    # Get the PDF data from the buffer
    pdf = buffer.getvalue()
    buffer.close()
    
    # Create a response object and attach the PDF
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename=report.pdf'
    return response

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)

