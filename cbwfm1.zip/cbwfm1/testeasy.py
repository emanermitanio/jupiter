from weasyprint import HTML

html = '<h1>Hello, world!</h1>'
pdf = HTML(string=html).write_pdf()

with open('test.pdf', 'wb') as f:
    f.write(pdf)
