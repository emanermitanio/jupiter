from flask import Blueprint, render_template, redirect

bp_login = Blueprint("login", __name__, template_folder='templates')

@bp_login.route('/')
def login():
     return render_template('login/login.html')
