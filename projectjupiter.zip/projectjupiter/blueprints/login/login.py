from flask import Blueprint, render_template, redirect, request, jsonify, session, url_for
from flask import flash, get_flashed_messages
import sqlite3

bp_login = Blueprint("login", __name__, template_folder='templates')

def db_conn():
     conn = sqlite3.connect('jupiter.db', check_same_thread=False)
     conn.row_factory = sqlite3.Row
     return conn

@bp_login.route('/')
def login():
     session.clear()
     return render_template('login/login.html')

@bp_login.route('/userlogin', methods=['POST'])
def userlogin():

     if request.method == 'POST':
          emp_sid = request.form['emp_sid']
          emp_pass = request.form['emp_pass']

          conn = db_conn()
          cursor = conn.cursor()
          cursor.execute("SELECT * FROM TBL_USER WHERE LOWER(EMP_SID) = ? AND EMP_PASSWORD = ?", (emp_sid.lower(), emp_pass))
          user = cursor.fetchone()
          cursor.close()

          if user:
                    session['ses_empsid'] = user['EMP_SID']
                    session['ses_empname'] = user['EMP_NAME']

                    return redirect(url_for('home.home'))
          else:
                     flash('Invalid User credentials. Please try again.', 'danger')
                     return render_template('login/login.html')
                     

     