from flask import Blueprint, render_template, redirect, session, request, flash
import sqlite3
from datetime import datetime, timedelta
import pytz
import plotly.graph_objs as go

bp_jup1001 = Blueprint('JUP1001', __name__, template_folder='templates')

def db_conn():
    conn = sqlite3.connect('jupiter.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


@bp_jup1001.route('/home')
def home():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')

    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get user attendance data
        qry = ''' 
        SELECT SHIFT_DT, 
            WORKSETUP,
            a.EMP_SID,
       -- Combine components for TS_START
           SUBSTR(TS_LOGIN, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGIN, 15, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGIN, 15, 2)
        ELSE 
            SUBSTR(TS_LOGIN, 15, 2)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGIN, 18, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGIN, 18, 2)
        ELSE 
            SUBSTR(TS_LOGIN, 18, 2)
    END || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_LOGIN
,

            -- Combine components for TS_END
             SUBSTR(TS_LOGOUT, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGOUT, 15, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGOUT, 15, 2)
        ELSE 
            SUBSTR(TS_LOGOUT, 15, 2)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGOUT, 18, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGOUT, 18, 2)
        ELSE 
            SUBSTR(TS_LOGOUT, 18, 2)
    END || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_LOGOUT
           ,
            ROUND(
                (julianday(TS_LOGOUT) - julianday(TS_LOGIN)) * 24, 
                2
            ) AS MINUTE_SPENT,
            u.EMP_NAME
        FROM TBL_ATTENDANCE a
        
        JOIN TBL_USER u ON u.EMP_SID = a.EMP_SID
        WHERE a.EMP_SID = ?
        ORDER BY SHIFT_DT DESC;

        '''
        cursor.execute(qry, (usersid,))
        data = cursor.fetchall()

        #check if there is an active shift
        cursor.execute('SELECT ID FROM TBL_ATTENDANCE WHERE TS_LOGOUT IS NULL and EMP_SID= ?',(usersid,) )
        x = cursor.fetchall()

        qry = '''
                        SELECT * FROM TBL_APPLIST WHERE ACTIVE = 1 ORDER BY APPID
                    '''
        cursor.execute(qry)
        applist = cursor.fetchall()
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()
        
        return render_template('JUP1001/home.html', usersid=usersid, username=username, data= data, x=x, userprofile=userprofile,myapp=myapp)
    else:
        return redirect('/')

@bp_jup1001.route('/endday',methods=['POST'])
def endday():
    usersid = session.get('ses_empsid')

    conn = db_conn()
    cursor = conn.cursor()
    #end all active shift without logout
    eastern = pytz.timezone('US/Eastern')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    cursor.execute('UPDATE TBL_ATTENDANCE SET TS_LOGOUT = ? WHERE EMP_SID =? AND TS_LOGOUT IS NULL', 
                   (current_datetime, usersid))
    conn.commit()
    conn.close()

    flash('SUCCESS: Shift ended.', 'success')

    return redirect('/JUP1001/home')


@bp_jup1001.route('/startday', methods=['POST'])
def startday():
    shiftdt = request.form['shiftdt']
    worksetup = request.form['worksetup']
    usersid = session.get('ses_empsid')


    #check first if shift date and employee sid already exists

    conn = db_conn()
    cursor = conn.cursor()

    cursor.execute('SELECT ID FROM TBL_ATTENDANCE WHERE SHIFT_DT = ? AND EMP_SID = ?', (shiftdt, usersid))
    x = cursor.fetchall()

    if x: #record exists
         flash('ERROR: Shift already exists for ' + shiftdt, 'danger')
    else:
        process_startday(shiftdt, worksetup, usersid)
    return redirect('/JUP1001/home')

def process_startday(shiftdt, worksetup, usersid):
    eastern = pytz.timezone('US/Eastern')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    conn = db_conn()
    cursor = conn.cursor()

    cursor.execute('INSERT INTO TBL_ATTENDANCE (SHIFT_DT, EMP_SID, TS_LOGIN, WORKSETUP) VALUES (?, ?, ?, ?)', (shiftdt, usersid, current_datetime, worksetup))
    conn.commit()

    #add record to TBL ACTIVITY
    qry = '''
        INSERT INTO TBL_ACTIVITY (EMP_SID, SHIFT_DT, TS_START, TS_END, FUNCTION_NM, ACTIVITY_TYPE)
        VALUES (?, ?, ?, ?, ?, ?);
    '''
    cursor.execute(qry, (usersid,shiftdt,current_datetime,current_datetime,'LOGIN','ATTENDANCE'))
    conn.commit()
    
    conn.close()
    flash('SUCCESS: Shift added successfully for ' + shiftdt, 'success')


@bp_jup1001.route('/dailyperformance')
def dailyperf():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')
    
    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get userprofile
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()

        #get activity history
        qry='''
SELECT SHIFT_DT,
        -- Combine components for TS_START
        SUBSTR(TS_START, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_START, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 15, 2)) = 1 THEN '0' || SUBSTR(TS_START, 15, 2)
            ELSE SUBSTR(TS_START, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 18, 2)) = 1 THEN '0' || SUBSTR(TS_START, 18, 2)
            ELSE SUBSTR(TS_START, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_START,
        -- Combine components for TS_END
        SUBSTR(TS_END, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_END, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 15, 2)) = 1 THEN '0' || SUBSTR(TS_END, 15, 2)
            ELSE SUBSTR(TS_END, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 18, 2)) = 1 THEN '0' || SUBSTR(TS_END, 18, 2)
            ELSE SUBSTR(TS_END, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_END,
        ROUND(
            (julianday(TS_END) - julianday(TS_START)) * 24 * 60,
            2
        ) AS MINUTE_SPENT,
        ACTIVITY_TYPE,
        FUNCTION_NM,
        CASENUMBER,
        REVIEW_STATUS_1
    FROM TBL_ACTIVITY
    WHERE EMP_SID = ?
    ORDER BY ID DESC;
        '''
        cursor.execute(qry,(usersid,))
        activity = cursor.fetchall()
        return render_template('JUP1001/dailysummary.html', usersid=usersid, username=username, userprofile=userprofile,myapp=myapp,activity=activity)
  
    else:
        return redirect('/')    
    
@bp_jup1001.route('/nonprod')
def nprod():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')
    
    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get userprofile
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()

        #get all non prod activities
        qry='''
        SELECT SHIFT_DT,
        FUNCTION_NM,
        EMP_COMMENTS,
        -- Combine components for TS_START
        SUBSTR(TS_START, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_START, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 15, 2)) = 1 THEN '0' || SUBSTR(TS_START, 15, 2)
            ELSE SUBSTR(TS_START, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 18, 2)) = 1 THEN '0' || SUBSTR(TS_START, 18, 2)
            ELSE SUBSTR(TS_START, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_START,
        -- Combine components for TS_END
        SUBSTR(TS_END, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_END, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 15, 2)) = 1 THEN '0' || SUBSTR(TS_END, 15, 2)
            ELSE SUBSTR(TS_END, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 18, 2)) = 1 THEN '0' || SUBSTR(TS_END, 18, 2)
            ELSE SUBSTR(TS_END, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_END,
        ROUND(
            (julianday(TS_END) - julianday(TS_START)) * 24 * 60,
            2
        ) AS MINUTE_SPENT
    FROM TBL_ACTIVITY
    WHERE EMP_SID = ?
        AND ACTIVITY_TYPE = 'NONPRODUCTION'
    ORDER BY ID DESC;
        ''' 
        cursor.execute(qry,(usersid,))
        data = cursor.fetchall()
        return render_template('JUP1001/nonprod.html', usersid=usersid, username=username, userprofile=userprofile,myapp=myapp,data=data)
  
    else:
        return redirect('/')   
      
@bp_jup1001.route('/tracknprod', methods=['POST'])
def tracknprod():
    usersid = session.get('ses_empsid')
    nprod = request.form['nprod']
    comments = request.form['comments']

    if usersid:
        conn = db_conn()
        cursor = conn.cursor()

        #check if there is active shift
        cursor.execute('SELECT ID, SHIFT_DT FROM TBL_ATTENDANCE WHERE TS_LOGOUT IS NULL AND EMP_SID = ?', (usersid,))
        r = cursor.fetchone()

        if r:
            shiftid = r[0]
            shiftdt = r[1]

            cursor.execute('SELECT MAX(TS_END) FROM TBL_ACTIVITY WHERE EMP_SID = ?', (usersid,))
            ts = cursor.fetchone()
            tsstart = ts[0]

            cursor.execute('SELECT DEPARTMENT, WORKGROUP, FUNCTION_GROUP FROM TBL_USER WHERE EMP_SID = ? ', (usersid,))
            result = cursor.fetchone()
            dept =result[0]
            wgroup = result[1]
            fgroup = result[2]
            
            eastern = pytz.timezone('US/Eastern')
            tsend = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')


            #insert non prod activity to TBL_ACTIVITY
            qry = '''
            INSERT INTO TBL_ACTIVITY (EMP_SID, SHIFT_DT, TS_START, TS_END, DEPARTMENT, WORKGROUP, FUNCTION_GROUP, FUNCTION_NM, ACTIVITY_TYPE, EMP_COMMENTS)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            ''' 
            cursor.execute(qry, (usersid,shiftdt,tsstart,tsend,dept,wgroup,fgroup,nprod,'NONPRODUCTION',comments))    
            conn.commit()

            conn.close()

            flash('SUCCESS: Non production activity - ' + nprod + ' tracked.', 'success')
        
        else:
            flash('ERROR: No active shift found. Please log attendance for today to track activities.', 'danger')

    return redirect('/JUP1001/nonprod')

@bp_jup1001.route('/prod')
def prod():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')
    
    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get userprofile
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()

        #get all non prod activities
        qry='''
        SELECT SHIFT_DT,
        FUNCTION_NM,
        EMP_COMMENTS,
        -- Combine components for TS_START
        SUBSTR(TS_START, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_START, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 15, 2)) = 1 THEN '0' || SUBSTR(TS_START, 15, 2)
            ELSE SUBSTR(TS_START, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 18, 2)) = 1 THEN '0' || SUBSTR(TS_START, 18, 2)
            ELSE SUBSTR(TS_START, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_START,
        -- Combine components for TS_END
        SUBSTR(TS_END, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_END, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 15, 2)) = 1 THEN '0' || SUBSTR(TS_END, 15, 2)
            ELSE SUBSTR(TS_END, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 18, 2)) = 1 THEN '0' || SUBSTR(TS_END, 18, 2)
            ELSE SUBSTR(TS_END, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_END,
        ROUND(
            (julianday(TS_END) - julianday(TS_START)) * 24 * 60,
            2
        ) AS MINUTE_SPENT
    FROM TBL_ACTIVITY
    WHERE EMP_SID = ?
        AND ACTIVITY_TYPE = 'NONPRODUCTION'
    ORDER BY TS_START DESC;
        ''' 
        cursor.execute(qry,(usersid,))
        data = cursor.fetchall()
        return render_template('JUP1001/prod.html', usersid=usersid, username=username, userprofile=userprofile,myapp=myapp,data=data)
  
    else:
        return redirect('/')   
