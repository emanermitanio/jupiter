from flask import Blueprint, render_template, redirect, session, url_for
from flask import flash, get_flashed_messages
import sqlite3

bp_home = Blueprint('home', __name__, template_folder='templates')

def db_conn():
    conn = sqlite3.connect('jupiter.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

@bp_home.route('/')
def home():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')    

    if usersid:

        conn = db_conn()
        cursor = conn.cursor()
        #retrieve all Jupiter Applications
        qry = '''
            SELECT * FROM TBL_APPLIST WHERE ACTIVE = 1 ORDER BY APPID
        '''

        cursor.execute(qry)
        applist = cursor.fetchall()
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()
        conn.close()

        return render_template('home/home.html', usersid=usersid, username=username, applist=applist, userprofile=userprofile, myapp=myapp)
    else:
        return redirect('/')
    
@bp_home.route('/<appid>')
def approute(appid):
    usersid = session.get('ses_empsid')
    conn = db_conn()
    cursor = conn.cursor()
    qry = '''
        SELECT EMP_SID FROM TBL_APPACCESS WHERE APPID =? AND EMP_SID =?
        '''
    cursor.execute(qry,(appid,usersid))
    access = cursor.fetchall()
    
    if access:
        return redirect(url_for('JUP1001.home'))
         
    else:
        flash('You do not have access to this application.', 'danger')

    return redirect('/home')