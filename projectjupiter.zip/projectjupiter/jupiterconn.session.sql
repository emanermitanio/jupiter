SELECT SHIFT_DT, 
            WORKSETUP,
            a.EMP_SID,

            
            -- Combine components for TS_START
           SUBSTR(TS_LOGIN, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGIN, 15, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGIN, 15, 2)
        ELSE 
            SUBSTR(TS_LOGIN, 15, 2)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGIN, 18, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGIN, 18, 2)
        ELSE 
            SUBSTR(TS_LOGIN, 18, 2)
    END || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_LOGIN
,

            -- Combine components for TS_END
             SUBSTR(TS_LOGOUT, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGOUT, 15, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGOUT, 15, 2)
        ELSE 
            SUBSTR(TS_LOGOUT, 15, 2)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGOUT, 18, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGOUT, 18, 2)
        ELSE 
            SUBSTR(TS_LOGOUT, 18, 2)
    END || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_LOGOUT
           ,
            ROUND(
                (julianday(TS_LOGOUT) - julianday(TS_LOGIN)) * 24, 
                2
            ) AS MINUTE_SPENT,
            u.EMP_NAME,

        FROM TBL_ATTENDANCE a
        
        JOIN TBL_USER u ON u.EMP_SID = a.EMP_SID
        
        WHERE a.EMP_SID = ?
        ORDER BY TS_LOGIN DESC;
