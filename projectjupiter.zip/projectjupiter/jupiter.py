from flask import Flask
from blueprints.login.login import bp_login
from blueprints.home.home import bp_home

app = Flask('__name__')
app.register_blueprint(bp_login)
app.register_blueprint(bp_home, url_prefix='/home')

if __name__ == '__main__':
    app.run(debug=True)