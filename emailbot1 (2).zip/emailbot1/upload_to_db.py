import sqlite3
from classify_emails import classify_email
from fetch_emails import fetch_emails

def create_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS emails (
            id INTEGER PRIMARY KEY,
            entry_id TEXT,
            subject TEXT,
            sender TEXT,
            body TEXT,
            classification TEXT,
            disposition TEXT
        )
    ''')
    conn.commit()
    conn.close()

def upload_to_db(email_data):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    for entry_id, subject, sender, body in email_data:
        classification = classify_email(subject, body)
        cursor.execute('''INSERT INTO emails (entry_id, subject, sender, body, classification, disposition)
                          VALUES (?, ?, ?, ?, ?, ?)''', (entry_id, subject, sender, body, classification, 'Pending'))

    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_db()
    email_data = fetch_emails()
    upload_to_db(email_data)
