import os
from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from exchangelib import DELEGATE, Account, Credentials, Configuration, Message

app = Flask(__name__)

def move_email_to_completed(entry_id):
    email = os.getenv('EMAIL')
    password = os.getenv('PASSWORD')
    exchange_server = os.getenv('EXCHANGE_SERVER')

    credentials = Credentials(email, password)
    config = Configuration(server=exchange_server, credentials=credentials)
    account = Account('shared_mailbox@example.com', config=config, autodiscover=False, access_type=DELEGATE)

    item = Message(account=account, message_id=entry_id)
    completed_folder = account.root / 'Completed'
    item.move(completed_folder)

@app.route('/')
def index():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, subject, sender, body, disposition FROM emails")
    emails = cursor.fetchall()
    conn.close()
    return render_template('view_email.html', emails=emails)

@app.route('/update_disposition', methods=['POST'])
def update_disposition():
    email_id = request.form['email_id']
    new_disposition = request.form['disposition']

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE emails SET disposition = ? WHERE id = ?", (new_disposition, email_id))
    conn.commit()

    if new_disposition == 'Completed':
        cursor.execute("SELECT entry_id FROM emails WHERE id = ?", (email_id,))
        entry_id = cursor.fetchone()[0]
        move_email_to_completed(entry_id)

    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
