import os
from exchangelib import DELEGATE, Account, Credentials, Configuration

def fetch_emails():
    email = os.getenv('EMAIL')
    password = os.getenv('PASSWORD')
    exchange_server = os.getenv('EXCHANGE_SERVER')

    credentials = Credentials(email, password)
    config = Configuration(server=exchange_server, credentials=credentials)
    account = Account('shared_mailbox@example.com', config=config, autodiscover=False, access_type=DELEGATE)

    inbox = account.inbox
    email_data = []

    for item in inbox.all().order_by('-datetime_received')[:100]:
        entry_id = item.message_id
        subject = item.subject
        sender = item.sender.email_address
        body = item.body
        email_data.append((entry_id, subject, sender, body))

    return email_data
