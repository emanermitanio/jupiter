from flask import Flask, url_for,render_template, request, flash, get_flashed_messages, redirect,session
import sqlite3
from datetime import datetime, timedelta
import pytz

app = Flask(__name__)
app.secret_key = 'wfmsecretkey'

def get_db_connection():
    conn = sqlite3.connect('wfm.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


@app.route('/')
def home():
    conn = get_db_connection()
    cursor = conn.cursor()

    #checklist available
    cursor.execute("SELECT FUNCTION_NM FROM TBL_CHECKLIST GROUP BY FUNCTION_NM")
    checklist = cursor.fetchall()

    #get all audit
    qry = '''
SELECT
    c.FUNCTION_NM, 
    a.CASENUMBER, 
    a.DT_REVIEW,
    COUNT(CASE WHEN a.RESULT IN ('PASS', 'FAIL', 'NA') THEN 1 END) AS total_completed,
    COUNT(CASE WHEN a.RESULT = 'PENDING' THEN 1 END) AS total_pending,
    ROUND(COUNT(CASE WHEN a.RESULT IN ('PASS', 'FAIL', 'NA') THEN 1 END) * 100.0 / NULLIF(COUNT(CASE WHEN a.RESULT IN ('PASS', 'FAIL', 'NA') THEN 1 END) + COUNT(CASE WHEN a.RESULT = 'PENDING' THEN 1 END), 0), 2) AS compl_rt,
    CASE 
        WHEN COUNT(CASE WHEN a.RESULT = 'PENDING' THEN 1 END) = 0 THEN 'COMPLETE'
        ELSE 'PENDING'
    END AS STATUS,
    a.SID_REVIEWER, 
    r.EMP_NAME
FROM 
    TBL_AUDIT a
JOIN TBL_CHECKLIST c ON a.CHKPT_ID = c.CHKPT_ID
LEFT JOIN TBL_ROSTER r ON a.SID_REVIEWER = r.EMP_SID
GROUP BY 
    a.CASENUMBER, 
    a.DT_REVIEW, 
    a.SID_REVIEWER;


            '''
    cursor.execute(qry)
    data = cursor.fetchall()

    return render_template('home.html',checklist=checklist,data=data)

@app.route('/createworkflow', methods=['POST'])
def createworkflow():
    mychecklist = request.form['mychecklist']
    casenumber = request.form['casenumber']
    sidreviewer = request.form['sidreviewer']

    
    eastern = pytz.timezone('US/Eastern')
    dt_rev = datetime.now(eastern).date()

    conn = get_db_connection()
    cursor = conn.cursor()
    qry = '''
    INSERT INTO TBL_AUDIT (CHKPT_ID, CASENUMBER, RESULT, DT_REVIEW, SID_REVIEWER)
            SELECT
                CHKPT_ID,
                ? AS CASENUMBER, 
                ? AS RESULT,
                ? AS DT_REVIEW,
                ? AS SID_REVIEWER

            FROM TBL_CHECKLIST
            WHERE FUNCTION_NM = ?   
    '''
    cursor.execute(qry,(casenumber,'PENDING', dt_rev, sidreviewer,mychecklist))
    conn.commit()

    flash('SUCCESS: Workflow successfully created - ' + mychecklist)


    return redirect('/')

@app.route('/workflow/<fname>/<casenumber>/<dtrev>/<sid>')
def workflow(fname,casenumber,dtrev,sid):

    session['f_fname'] = fname
    session['f_casenumber'] = casenumber
    session['f_dtrev'] = dtrev
    session['f_sid'] = sid

    url = url_for('workflow', fname=fname, casenumber=casenumber, dtrev=dtrev, sid=sid)
    
    session['f_url'] = url


    f_cat = session.get('f_cat')


    conn = get_db_connection()
    cursor = conn.cursor()

    if f_cat is None:
        qry = '''
        SELECT a.ID, a.CASENUMBER, a.DT_REVIEW, a.SID_REVIEWER, a.RESULT,
        c.FUNCTION_NM, c.CATEGORY, c.QUESTION, c.OBS_TEMPLATE, c.IOP, c.SORT
        FROM TBL_AUDIT a
        JOIN TBL_CHECKLIST c ON a.CHKPT_ID = c.CHKPT_ID
        WHERE a.CASENUMBER = ? AND c.FUNCTION_NM = ? AND a.DT_REVIEW = ? AND a.SID_REVIEWER = ?
        '''
        cursor.execute(qry,(casenumber,fname,dtrev,sid))
    elif f_cat == 'FAIL':
        qry = '''
        SELECT a.ID, a.CASENUMBER, a.DT_REVIEW, a.SID_REVIEWER, a.RESULT,
        c.FUNCTION_NM, c.CATEGORY, c.QUESTION, c.OBS_TEMPLATE, c.IOP, c.SORT
        FROM TBL_AUDIT a
        JOIN TBL_CHECKLIST c ON a.CHKPT_ID = c.CHKPT_ID
        WHERE a.CASENUMBER = ? AND c.FUNCTION_NM = ? AND a.DT_REVIEW = ? AND a.SID_REVIEWER = ? AND a.RESULT = 'FAIL'
        '''
        cursor.execute(qry,(casenumber,fname,dtrev,sid))
    else:
        qry = '''
            SELECT a.ID, a.CASENUMBER, a.DT_REVIEW, a.SID_REVIEWER, a.RESULT,
            c.FUNCTION_NM, c.CATEGORY, c.QUESTION, c.OBS_TEMPLATE, c.IOP, c.SORT
            FROM TBL_AUDIT a
            JOIN TBL_CHECKLIST c ON a.CHKPT_ID = c.CHKPT_ID
            WHERE a.CASENUMBER = ? AND c.FUNCTION_NM = ? AND a.DT_REVIEW = ? AND a.SID_REVIEWER = ? AND c.CATEGORY=?
        '''
        cursor.execute(qry,(casenumber,fname,dtrev,sid,f_cat))

    result = cursor.fetchall()

   #get categories and pending
    qry = '''
    SELECT
    c.CATEGORY,
    COUNT(CASE WHEN a.RESULT = 'PENDING' THEN 1 END) AS total_pending
    FROM TBL_AUDIT a
    JOIN TBL_CHECKLIST c ON a.CHKPT_ID = c.CHKPT_ID

    WHERE a.CASENUMBER = ? AND c.FUNCTION_NM = ? AND a.DT_REVIEW = ? AND a.SID_REVIEWER = ?
    
    GROUP BY 
    c.CATEGORY
    ORDER BY c.SORT
    '''
    cursor.execute(qry,(casenumber,fname,dtrev,sid))
    categories = cursor.fetchall()

   
    return render_template('workflow.html',fname=fname, casenumber=casenumber,result=result,categories=categories)

@app.route('/filterchecklist/<catfilter>')
def filterchecklist(catfilter):

    session['f_cat'] = catfilter

    fname = session.get('f_fname')
    casenumber = session.get('f_casenumber')
    dtrev = session.get('f_dtrev')
    sid = session.get('f_sid')

    return redirect(f'/workflow/{fname}/{casenumber}/{dtrev}/{sid}')

@app.route('/savecheckpoint', methods=['POST'])
def savecheckpoint():
    recordid = request.form['recordid']
    comments = request.form['revcomments']
    current_url = session.get('f_url')

    conn=get_db_connection()
    cursor = conn.cursor()

    if request.form.get('submit_btn') == 'btnPass':
        result = 'PASS'
    elif request.form.get('submit_btn') == 'btnFail':
        result = 'FAIL'
    elif request.form.get('submit_btn') == 'btnNA':
        result = 'NA'

    qry = '''
            UPDATE TBL_AUDIT SET RESULT = ?, COMMENTS = ? 
            WHERE ID = ?
            '''
    cursor.execute(qry, (result,comments,recordid))
    conn.commit()
    conn.close()

    return redirect(current_url)


@app.route('/showfailitems')
def showfailitems():
    current_url = session.get('f_url')

    session['f_cat'] = 'FAIL'
    return redirect(current_url)

@app.route('/showallitems')
def showallitems():
    current_url = session.get('f_url')

    session['f_cat'] = None
    return redirect(current_url)

if __name__ == '__main__':
    app.run(debug=True)
