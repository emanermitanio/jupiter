// Sample dynamic data
const checklistData = [
    { id: 'row1', question: 'PURCHASE CONTRACT', checkpoint: 'PURCHASE CONTRACT PRESENT', template: 'Purchase Contract is missing'},
    { id: 'row2', question: 'PAGES', checkpoint: 'PURCHASE CONTRACT MISSING PAGES', template: 'Purchase contract is missing page [specify page/s]' },
    { id: 'row3', question: 'SIGNATURES', checkpoint: 'PURCHASE CONTRACT MISSING BUYER', template: 'Missing Customer signature' },
    { id: 'row4', question: 'SIGNATURES', checkpoint: 'PURCHASE CONTRACT MISSING BROKER', template: 'Missing Brooker signature' },
    { id: 'row5', question: 'SIGNATURES', checkpoint: 'PURCHASE CONTRACT MISSING SELLER', template: 'Missing Seller signature' },
    // Add more data as needed
];

// Populate table rows dynamically
const checklistBody = document.getElementById('checklistBody');
checklistData.forEach(item => {
    const row = document.createElement('tr');
    row.id = item.id;

    const radioTd = document.createElement('td');
    const gridObsDiv = document.createElement('div');
    gridObsDiv.className = 'grid-obs';

    const passRadio = createRadio(item.id, 'PASS', 'PASS');
    const failRadio = createRadio(item.id, 'FAIL', 'FAIL');
    const naRadio = createRadio(item.id, 'NA', 'NA');

    gridObsDiv.appendChild(passRadio);
    gridObsDiv.appendChild(failRadio);
    gridObsDiv.appendChild(naRadio);

    radioTd.appendChild(gridObsDiv);
    row.appendChild(radioTd);

    const questionTd = document.createElement('td');
    questionTd.textContent = item.question;
    row.appendChild(questionTd);

    const checkpointTd = document.createElement('td');
    checkpointTd.textContent = item.checkpoint;
    row.appendChild(checkpointTd);

    const templateTd = document.createElement('td');
    templateTd.textContent = item.template;
    templateTd.classList.add('obstemplate'); // Add your desired class name here
    row.appendChild(templateTd);

    checklistBody.appendChild(row);
});

// Array to store failed items
let failedItemsArray = [];

function createRadio(question, value, label) {
    const radio = document.createElement('input');
    const rowId = question.replace(/\s+/g, '-'); // Generate a unique ID from the question text
    radio.className = 'form-check-input';
    radio.type = 'radio';
    radio.name = `${rowId}Radio`;
    radio.id = `${rowId}${value}`;
    radio.value = value;
    radio.dataset.question = question; // Store the question as a data attribute
    radio.onchange = () => {
        if (value === 'FAIL') {
            openModal(rowId);
            // Add the failed item's question to the array if not already present
            if (!failedItemsArray.includes(question)) {
                failedItemsArray.push(question);
            }
        } else {
            // Remove the question from the array if the radio button is marked as pass or NA
            const index = failedItemsArray.indexOf(question);
            if (index !== -1) {
                failedItemsArray.splice(index, 1);
            }
        }
    };

    const radioLabel = document.createElement('label');
    radioLabel.className = 'form-check-label';
    radioLabel.htmlFor = `${rowId}${value}`;
    radioLabel.textContent = label;

    const radioDiv = document.createElement('div');
    radioDiv.className = 'form-check';
    radioDiv.appendChild(radio);
    radioDiv.appendChild(radioLabel);

    return radioDiv;
}
