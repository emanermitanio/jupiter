function openModal(rowId) {
    const checkpointDetails = getCheckpointDetails(rowId);
    const revcomments = getRevComments(rowId);
    document.getElementById('checkpointDetails').textContent = checkpointDetails;
    document.getElementById('revcomments').textContent = revcomments;
    const modal = new bootstrap.Modal(document.getElementById('checkpointModal'));
    modal.show();
}

function getCheckpointDetails(rowId) {
    const row = document.getElementById(rowId);
    if (row) {
        const checkpoint = row.cells[2].textContent; // Get the content of the third <td> element
        return checkpoint;
    }
    return "Checkpoint not found";
}

function getRevComments(rowId) {
    const row = document.getElementById(rowId);
    if (row) {
        const revcomment = row.cells[3].textContent; // Get the content of the third <td> element
        return revcomment;
    }
    return "Checkpoint not found";
}
