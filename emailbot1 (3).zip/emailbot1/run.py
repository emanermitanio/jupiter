from app import app
import load_env

if __name__ == '__main__':
    app.run(debug=True)
