import os
from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import win32com.client
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

def fetch_emails():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.Folders.Item(os.getenv('EMAIL')).Folders.Item('Inbox')
    messages = inbox.Items
    email_data = []

    for message in messages:
        entry_id = message.EntryID
        subject = message.Subject
        sender = message.SenderEmailAddress
        body = message.Body
        email_data.append((entry_id, subject, sender, body))

    return email_data

def move_email_to_completed(entry_id):
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    inbox = outlook.Folders.Item(os.getenv('EMAIL')).Folders.Item('Inbox')
    message = inbox.Items.Find(f"[EntryID]='{entry_id}'")
    completed_folder = outlook.Folders.Item(os.getenv('EMAIL')).Folders.Item('Completed')
    message.Move(completed_folder)

@app.route('/')
def index():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id, subject, sender, body, disposition FROM emails")
    emails = cursor.fetchall()
    conn.close()
    return render_template('view_email.html', emails=emails)

@app.route('/update_disposition', methods=['POST'])
def update_disposition():
    email_id = request.form['email_id']
    new_disposition = request.form['disposition']

    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("UPDATE emails SET disposition = ? WHERE id = ?", (new_disposition, email_id))
    conn.commit()

    if new_disposition == 'Completed':
        cursor.execute("SELECT entry_id FROM emails WHERE id = ?", (email_id,))
        entry_id = cursor.fetchone()[0]
        move_email_to_completed(entry_id)

    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
