import sqlite3
from app.routes import fetch_emails

def create_database():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS emails (
            id INTEGER PRIMARY KEY,
            entry_id TEXT,
            subject TEXT,
            sender TEXT,
            body TEXT,
            disposition TEXT
        )
    ''')
    conn.commit()
    conn.close()

def insert_emails():
    emails = fetch_emails()
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    for email in emails:
        cursor.execute('''
            INSERT INTO emails (entry_id, subject, sender, body, disposition)
            VALUES (?, ?, ?, ?, 'Pending')
        ''', email)
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_database()
    insert_emails()
