def classify_email(subject, body):
    if "urgent" in subject.lower() or "urgent" in body.lower():
        return "Urgent"
    # Add more classification logic here
    return "Normal"
