from flask import Flask, url_for, render_template, request, flash, get_flashed_messages, redirect, session, Response
import sqlite3
from datetime import datetime, timedelta
import pytz

app = Flask(__name__)
app.secret_key = 'mysecretkey'

def dbconn():
    conn = sqlite3.connect('wfm.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn
    
@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return render_template('login.html')

@app.route('/userlogin', methods=['POST'])
def userlogin():
    uid = request.form['usersid'].lower()
    upass = request.form['userpassword']

    qry = '''
        SELECT USERSID, USERNAME, ACCESS_LEVEL, DEPARTMENT, WORKGROUP FROM TBL_USERS WHERE LOWER(USERSID) = ? AND USER_PASSWORD = ?
                '''

    conn = dbconn()
    cursor = conn.cursor()
    cursor.execute(qry, (uid, upass))

    result = cursor.fetchone()
    conn.close()

    if result:
        # Register user to session storage
        usersid, username, access_level, dept, wgroup = result

        session['sess_usersid'] = usersid
        session['sess_username'] = username
        session['sess_accesslevel'] = access_level
        session['sess_department'] = dept
        session['sess_workgroup'] = wgroup

        return redirect('/home')
    else:
        flash('Invalid User SID/Password')
        return render_template('login.html')


@app.route('/home')
def home():
    uid = session.get('sess_usersid')
    if uid:
        usersid = session.get('sess_usersid')   
        username = session.get('sess_username')
        access_level = session.get('sess_accesslevel')
        dept = session.get('sess_department')
        wgroup = session.get('sess_workgroup')

        conn = dbconn()
        cursor = conn.cursor()
        cursor.execute("SELECT CHECKLIST FROM TBL_CHECKLIST WHERE CHKPT_ID > 0 GROUP BY CHECKLIST")
        check_list = cursor.fetchall()
        return render_template('home.html',check_list=check_list,usersid=usersid,username=username,access_level=access_level,dept=dept,wgroup=wgroup)
    else:
        return redirect('/login')
    
@app.route('/adminchecklist')
def adminchecklist():
    access_level = session.get('sess_accesslevel')
    if access_level == 5:
        usersid = session.get('sess_usersid')   
        username = session.get('sess_username')
        access_level = session.get('sess_accesslevel')
        dept = session.get('sess_department')
        wgroup = session.get('sess_workgroup')

        conn = dbconn()
        cursor = conn.cursor()
        qry = '''SELECT DEPARTMENT, 
       WORKGROUP, 
       CHECKLIST, 
       COALESCE(COUNT(CHKPT_ID), 0) AS Total_Checkpoints 
FROM TBL_CHECKLIST 

GROUP BY CHECKLIST;'''
        
        cursor.execute(qry)
        list_checklist = cursor.fetchall()
        
        return render_template('adminchecklist.html',usersid=usersid,username=username,access_level=access_level,dept=dept,wgroup=wgroup,list_checklist=list_checklist)
    else:
        session.pop('_flashes', None)
        flash('You do not have access to Administrator - Checklist')
        return redirect('/home')
    
@app.route('/createchecklist', methods=['POST'])
def createchecklist():
    
    dept = request.form.get('dept')
    wgroup = request.form.get('wgroup')
    checklist = request.form['checklist']

    conn = dbconn()
    cursor = conn.cursor()
    #check first if checklist name exists
    cursor.execute("SELECT CHECKLIST FROM TBL_CHECKLIST WHERE CHECKLIST = ?", (checklist,))

    r = cursor.fetchone()

    if r:
        flash('Checklist already exists in the database.')
    else:
        qry = '''
        INSERT INTO TBL_CHECKLIST (
            DEPARTMENT,
            WORKGROUP,
            CHECKLIST
        )
        VALUES (
            ?,
            ?,
            ?
        );
        '''
        cursor.execute(qry,(dept,wgroup,checklist))
        conn.commit()
        
        #get checklist

       
        conn.close()
        return redirect('/adminchecklist')

@app.route('/deleteOption', methods=['POST'])
def deleteOption():
    checklist = request.form['checklist']
    dept = request.form['dept']
    wgroup = request.form['wgroup']
    chkpt = request.form['chkpt']
    optionid = request.form['optionid']

    conn = dbconn()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM TBL_OPTION WHERE ID = ?",(optionid,))
    conn.commit()

    return redirect(url_for('editcheckpoints',dept=dept,wgroup=wgroup,checklist=checklist,chkpt=chkpt))

@app.route('/addSelection', methods=['POST'])
def addSelection():
    currURL = request.form['currURL']

    chkptid = request.form['chkptid']
    optionValue = request.form['optionValue']
    optionSort = request.form['optionSort']

    conn = dbconn()
    cursor = conn.cursor()
    qry = '''
    INSERT INTO TBL_OPTION (CHKPT_ID, SELECT_OPTION, ACTIVE, SORT)
    VALUES (
        ?,?,?,?
      );

      '''
    cursor.execute(qry,(chkptid,optionValue,1,optionSort))
    conn.commit()
    conn.close()

    return redirect(currURL)

@app.route('/editcheckpoints')
def editcheckpoints():
    var_checklist = request.args.get('checklist')
    var_dept = request.args.get('dept')
    var_wgroup = request.args.get('wgroup')
    var_chkptid = request.args.get('chkpt')

    conn = dbconn()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM TBL_CHECKLIST WHERE CHKPT_ID = ?", (var_chkptid,))
    checkpointDetails = cursor.fetchall()

    cursor.execute("SELECT o.*,c.* FROM TBL_OPTION o JOIN TBL_CHECKLIST c ON o.CHKPT_ID = c.CHKPT_ID WHERE o.CHKPT_ID = ?", (var_chkptid,))
    optionList = cursor.fetchall()

    cursor.execute("SELECT COUNT(*) FROM TBL_OPTION WHERE CHKPT_ID = ?", (var_chkptid,))
    optionCount = cursor.fetchone()[0]
    optionCount = optionCount + 1

    return render_template('/editcheckpoints.html',optionCount=optionCount,optionList=optionList,checkpointDetails=checkpointDetails,var_checklist=var_checklist,var_chkptid=var_chkptid,var_dept=var_dept,var_wgroup=var_wgroup)

@app.route('/admincheckpoint')
def admincheckpoint():
    var_checklist = request.args.get('checklist')
    var_dept = request.args.get('dept')
    var_wgroup = request.args.get('wgroup')

    access_level = session.get('sess_accesslevel')
    if access_level == 5:
        usersid = session.get('sess_usersid')   
        username = session.get('sess_username')
        access_level = session.get('sess_accesslevel')
        dept = session.get('sess_department')
        wgroup = session.get('sess_workgroup')

        conn = dbconn()
        cursor = conn.cursor()
        qry = '''SELECT * FROM TBL_CHECKLIST
WHERE DEPARTMENT = ? AND WORKGROUP = ? AND CHECKLIST = ? AND CHKPT_ID IS NOT NULL

ORDER BY SORT ASC;

'''
        
        cursor.execute(qry,(var_dept,var_wgroup,var_checklist))
        list_checkpoints = cursor.fetchall()
        
        return render_template('admincheckpoints.html',usersid=usersid,username=username,access_level=access_level,
                               var_dept=var_dept,var_wgroup=var_wgroup,var_checklist=var_checklist,
                               dept=dept,wgroup=wgroup,list_checkpoints=list_checkpoints)
    else:
        session.pop('_flashes', None)
        flash('You do not have access to Administrator - Checklist')
        return redirect('/home')

@app.route('/createcheckpoint', methods=['POST'])
def createcheckpoint():

    eastern = pytz.timezone('US/Eastern')
    dt_today = datetime.now(eastern).date()
    usersid = session.get('sess_usersid')  

    var_dept = request.form['var_dept']
    var_wgroup = request.form['var_wgroup']
    var_checklist = request.form['var_checklist']




    category = request.form['category']
    question = request.form['question']
    obstemplate = request.form['obstemplate']
    iop = request.form['iop']
    actionitem = request.form['actionitem']
    sort = request.form['sort']
    var_active = 1
    logtype = "CREATE"
    logdate = dt_today
    logby = usersid
    logcomments = "New Checkpoint"
    conn = dbconn()
    cursor = conn.cursor()

    cursor.execute("SELECT COALESCE(MAX(CHKPT_ID), 0) + 1 AS Next_CHKPT_ID FROM TBL_CHECKLIST;")
    var_chkptid = cursor.fetchone()[0]

    qry = '''
        INSERT INTO TBL_CHECKLIST (
CHKPT_ID, DEPARTMENT, WORKGROUP, CHECKLIST, CATEGORY, QUESTION, OBS_TEMPLATE, IOP,
ACTION_ITEM, SORT, ACTIVE, LOG_TYPE, DATE_LOGGED, LOGGED_BY, LOG_COMMENTS
  )
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
'''
    cursor.execute(qry,(var_chkptid,var_dept,var_wgroup,var_checklist,category,question,obstemplate,iop,
                        actionitem,sort,var_active,logtype,logdate,logby,logcomments))

    conn.commit()
    conn.close()

    return redirect(url_for('admincheckpoint',dept=var_dept,wgroup=var_wgroup,checklist=var_checklist))


def get_questions():
    conn = dbconn()
    cursor = conn.cursor()

    cursor.execute("SELECT c.QUESTION, a.CHKPT_ID, a.ID, a.REVIEW_RESULT, c.IOP, a.REVIEWER_COMMENTS FROM TBL_AUDIT a JOIN TBL_CHECKLIST c ON a.CHKPT_ID = c.CHKPT_ID")
    questions = cursor.fetchall()
    qna = []
    for question in questions:
        cursor.execute("SELECT SELECT_OPTION FROM TBL_OPTION WHERE CHKPT_ID=?",(question[1],))
        options = cursor.fetchall()
        qna.append((question,options))
    conn.close()  
    return qna         
    

@app.route('/myworkflow', methods=['GET', 'POST'])
def myworkflow():

    uid = session.get('sess_usersid')
    if uid:
        usersid = session.get('sess_usersid')   
        username = session.get('sess_username')
        access_level = session.get('sess_accesslevel')
        dept = session.get('sess_department')
        wgroup = session.get('sess_workgroup')
        
        if request.method == 'POST':
            selected_options = {key[8:]: value for key, value in request.form.items() if key.startswith('question')}
            print(selected_options)
            return redirect(url_for('/myworkflow'))
        
        questions = get_questions()
        return render_template('myworkflow.html', questions=questions, usersid=usersid,username=username,access_level=access_level,dept=dept,wgroup=wgroup)

    else:
        return redirect('/login') 
 

@app.route('/update_record', methods=['POST'])
def update_record():
    selected_option = request.form['selected_option']
    question_id = request.form['question_id']

    # Check if selected_option is None (meaning it's not a direct form field)
    if selected_option is None:
        # Try to get the selected option from the options dict
        selected_option = request.form.get('option_selected')

    # Update the record based on the selected option and question ID
    # Your code to update the record goes here
    conn = dbconn()
    cursor = conn.cursor()

    cursor.execute("UPDATE TBL_AUDIT SET REVIEW_RESULT = ? WHERE ID = ?", (selected_option, question_id))
    conn.commit()  # Don't forget to commit the transaction after executing the query
    conn.close()

    return Response(status=204)

@app.route('/addrevcomments', methods=['POST'])
def addrevcomments():
     revcomments = request.form['revcomments']
     recordid = request.form['recordid']

     conn = dbconn()
     cursor = conn.cursor()
     cursor.execute("UPDATE TBL_AUDIT SET REVIEWER_COMMENTS = ? WHERE ID = ?", (revcomments, recordid))
     conn.commit()
     conn.close()

    
     
     return redirect('/myworkflow')

@app.route('/createworkflow', methods=['POST'])
def createworkflow():
    usersid = session.get('sess_usersid')   
    checklist = request.form.get('checklist')
    casenumber = request.form['casenumber']
    
    eastern = pytz.timezone('US/Eastern')
    dt_rev = datetime.now(eastern).date()

    conn = dbconn()
    cursor = conn.cursor()
    qry = '''
    INSERT INTO TBL_AUDIT (CHKPT_ID, CASENUMBER, DT_REVIEW, SID_REVIEWER)
            SELECT
                CHKPT_ID,
                ? AS CASENUMBER, 
                ? AS DT_REVIEW,
                ? AS SID_REVIEWER

            FROM TBL_CHECKLIST
            WHERE CHECKLIST = ? AND ACTIVE = 1 AND CHKPT_ID > 0
    '''
    cursor.execute(qry,(casenumber, dt_rev, usersid, checklist))
    conn.commit()


    return redirect('/home')



if __name__ == '__main__':
    app.run(debug=True, port=8020, host='0.0.0.0')