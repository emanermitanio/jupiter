from exchangelib import DELEGATE, Account, Credentials, Configuration, Folder

def fetch_emails():
    credentials = Credentials('your_email@example.com', 'your_password')
    config = Configuration(server='your_exchange_server', credentials=credentials)
    account = Account('shared_mailbox@example.com', config=config, autodiscover=False, access_type=DELEGATE)

    inbox = account.inbox
    email_data = []

    for item in inbox.all().order_by('-datetime_received')[:100]:
        entry_id = item.message_id
        subject = item.subject
        sender = item.sender.email_address
        body = item.body
        email_data.append((entry_id, subject, sender, body))

    return email_data
