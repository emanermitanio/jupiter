from flask import Flask, render_template, request
import requests

app = Flask(__name__)

# Function to fetch data from the JSONPlaceholder API
def get_data(page=1):
    url = f"https://jsonplaceholder.typicode.com/posts?_page={page}&_limit=5"  # Limiting to 10 items per page
    response = requests.get(url)
    data = response.json()
    return data

@app.route('/')
def index():
    page = request.args.get('page', default=1, type=int)  # Get the page number from query parameter
    data = get_data(page)
    return render_template('index.html', data=data, page=page)

if __name__ == '__main__':
    app.run(debug=True)
