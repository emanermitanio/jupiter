from flask import Flask
from blueprints.login.login import bp_login
from blueprints.home.home import bp_home
from blueprints.JUP1001.jup1001 import bp_jup1001
from datetime import datetime, timedelta

app = Flask('__name__')
app.register_blueprint(bp_login)
app.register_blueprint(bp_home, url_prefix='/home')
app.register_blueprint(bp_jup1001, url_prefix='/JUP1001')

app.secret_key = 'jupitersuperkey'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=120)
app.config['UPLOAD_PATH'] = 'static/uploads'

if __name__ == '__main__':
    app.run(debug=True)