from flask import Blueprint, render_template, redirect, session, request, flash
import sqlite3
from datetime import datetime, timedelta
import pytz
import plotly.graph_objs as go


bp_jup1001 = Blueprint('JUP1001', __name__, template_folder='templates')


def db_conn():
    conn = sqlite3.connect('jupiter.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

#Month Dictionary
month_names = {
    '01': 'JANUARY',
    '02': 'FEBRUARY',
    '03': 'MARCH',
    '04': 'APRIL',
    '05': 'MAY',
    '06': 'JUNE',
    '07': 'JULY',
    '08': 'AUGUST',
    '09': 'SEPTEMBER',
    '10': 'OCTOBER',
    '11': 'NOVEMBER',
    '12': 'DECEMBER'
}


@bp_jup1001.route('/home')
def home():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')

 #session filter for activity month
    sdate = session.get('ses_sdate')

    if sdate is None:
        current_date = datetime.now()
        att_month = current_date.strftime('%m')
        att_year = current_date.strftime('%Y')
    else:
        att_year = sdate.split('-')[0]
        att_month = sdate.split('-')[1]

    if usersid:
        conn = db_conn()
        cursor = conn.cursor()

        #get user attendance data
        qry = ''' 
        SELECT 
        strftime('%Y', SHIFT_DT) AS SHIFT_YEAR,
        strftime('%m', SHIFT_DT) AS SHIFT_MONTH,
    SHIFT_DT, 
            WORKSETUP,
            a.EMP_SID,
       -- Combine components for TS_START
           SUBSTR(TS_LOGIN, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGIN, 15, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGIN, 15, 2)
        ELSE 
            SUBSTR(TS_LOGIN, 15, 2)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGIN, 18, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGIN, 18, 2)
        ELSE 
            SUBSTR(TS_LOGIN, 18, 2)
    END || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGIN, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_LOGIN
,

            -- Combine components for TS_END
             SUBSTR(TS_LOGOUT, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGOUT, 15, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGOUT, 15, 2)
        ELSE 
            SUBSTR(TS_LOGOUT, 15, 2)
    END || ':' || 
    CASE 
        WHEN LENGTH(SUBSTR(TS_LOGOUT, 18, 2)) = 1
            THEN '0' || SUBSTR(TS_LOGOUT, 18, 2)
        ELSE 
            SUBSTR(TS_LOGOUT, 18, 2)
    END || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_LOGOUT, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_LOGOUT
           ,
            ROUND(
                (julianday(TS_LOGOUT) - julianday(TS_LOGIN)) * 24, 
                2
            ) AS MINUTE_SPENT,
            u.EMP_NAME
        FROM TBL_ATTENDANCE a
        
        JOIN TBL_USER u ON u.EMP_SID = a.EMP_SID
        WHERE a.EMP_SID = ? AND SHIFT_YEAR = ? AND SHIFT_MONTH = ?
        ORDER BY SHIFT_DT DESC;

        '''
        cursor.execute(qry, (usersid,att_year,att_month))

        data = cursor.fetchall()

        #check if there is an active shift
        cursor.execute('SELECT ID FROM TBL_ATTENDANCE WHERE TS_LOGOUT IS NULL and EMP_SID= ?',(usersid,) )
        x = cursor.fetchall()

        qry = '''
                        SELECT * FROM TBL_APPLIST WHERE ACTIVE = 1 ORDER BY APPID
                    '''
        cursor.execute(qry)
        applist = cursor.fetchall()
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()
        return render_template('JUP1001/home.html', usersid=usersid, username=username, data= data, x=x, userprofile=userprofile,myapp=myapp)
    else:
        return redirect('/')

#resetattendancefilter
@bp_jup1001.route('/resetattendancefilter')
def resetattendancefilter():

    session.pop('ses_sdate', None)
    return redirect('/JUP1001/home')

#filterattendance
@bp_jup1001.route('/filterattendance', methods=['POST'])
def filterattendance():
    usersid = session.get('ses_empsid')
    sdate = request.form['sdate']    
    session['ses_sdate'] = sdate

    return redirect('/JUP1001/home')


#route.endday
@bp_jup1001.route('/endday',methods=['POST'])
def endday():
    usersid = session.get('ses_empsid')

    conn = db_conn()
    cursor = conn.cursor()
    #end all active shift without logout
    eastern = pytz.timezone('US/Eastern')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    cursor.execute('UPDATE TBL_ATTENDANCE SET TS_LOGOUT = ? WHERE EMP_SID =? AND TS_LOGOUT IS NULL', 
                   (current_datetime, usersid))
    conn.commit()
    conn.close()

    flash('SUCCESS: Shift ended.', 'success')

    return redirect('/JUP1001/home')

#route.startday
@bp_jup1001.route('/startday', methods=['POST'])
def startday():
    shiftdt = request.form['shiftdt']
    worksetup = request.form['worksetup']
    usersid = session.get('ses_empsid')


    #check first if shift date and employee sid already exists

    conn = db_conn()
    cursor = conn.cursor()

    cursor.execute('SELECT ID FROM TBL_ATTENDANCE WHERE SHIFT_DT = ? AND EMP_SID = ?', (shiftdt, usersid))
    x = cursor.fetchall()

    if x: #record exists
         flash('ERROR: Shift already exists for ' + shiftdt, 'danger')
    else:
        process_startday(shiftdt, worksetup, usersid)
    return redirect('/JUP1001/home')

def process_startday(shiftdt, worksetup, usersid):
    eastern = pytz.timezone('US/Eastern')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    conn = db_conn()
    cursor = conn.cursor()

    cursor.execute('INSERT INTO TBL_ATTENDANCE (SHIFT_DT, EMP_SID, TS_LOGIN, WORKSETUP) VALUES (?, ?, ?, ?)', (shiftdt, usersid, current_datetime, worksetup))
    conn.commit()

    #add record to TBL ACTIVITY
    qry = '''
        INSERT INTO TBL_ACTIVITY (EMP_SID, SHIFT_DT, TS_START, TS_END, FUNCTION_NM, ACTIVITY_TYPE)
        VALUES (?, ?, ?, ?, ?, ?);
    '''
    cursor.execute(qry, (usersid,shiftdt,current_datetime,current_datetime,'LOGIN','ATTENDANCE'))
    conn.commit()
    
    conn.close()
    flash('SUCCESS: Shift added successfully for ' + shiftdt, 'success')

#route.dailyperformance
@bp_jup1001.route('/dailyperformance')
def dailyperf():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')
    
    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get userprofile
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()

        #get activity history
        qry='''
SELECT SHIFT_DT,
        -- Combine components for TS_START
        SUBSTR(TS_START, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_START, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 15, 2)) = 1 THEN '0' || SUBSTR(TS_START, 15, 2)
            ELSE SUBSTR(TS_START, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 18, 2)) = 1 THEN '0' || SUBSTR(TS_START, 18, 2)
            ELSE SUBSTR(TS_START, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_START,
        -- Combine components for TS_END
        SUBSTR(TS_END, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_END, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 15, 2)) = 1 THEN '0' || SUBSTR(TS_END, 15, 2)
            ELSE SUBSTR(TS_END, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 18, 2)) = 1 THEN '0' || SUBSTR(TS_END, 18, 2)
            ELSE SUBSTR(TS_END, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_END,
        ROUND(
            (julianday(TS_END) - julianday(TS_START)) * 24 * 60,
            2
        ) AS MINUTE_SPENT,
        ACTIVITY_TYPE,
        FUNCTION_NM,
        CASENUMBER,
        REVIEW_STATUS_1
    FROM TBL_ACTIVITY
    WHERE EMP_SID = ?
    ORDER BY ID DESC;
        '''
        cursor.execute(qry,(usersid,))
        activity = cursor.fetchall()
        return render_template('JUP1001/dailysummary.html', usersid=usersid, username=username, userprofile=userprofile,myapp=myapp,activity=activity)
  
    else:
        return redirect('/')    

#filterattendance
@bp_jup1001.route('/filternprod', methods=['POST'])
def filternprod():
    nprodmonth = request.form['nprodmonth']    
    session['ses_nprodmonth'] = nprodmonth

    return redirect('/JUP1001/nonprod')


#route.resetnonprod
@bp_jup1001.route('/resetnonprod')
def resetnonprod():
    session.pop('ses_nprodmonth', None)
    return redirect('/JUP1001/nonprod')

#route.nonprod
@bp_jup1001.route('/nonprod')
def nprod():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')

    nprodmonth = session.get('ses_nprodmonth')

    if nprodmonth is None:
        current_date = datetime.now()
        att_month = current_date.strftime('%m')
        att_year = current_date.strftime('%Y')
    else:
        att_year = nprodmonth.split('-')[0]
        att_month = nprodmonth.split('-')[1]

    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get userprofile
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()

        #get all non prod activities
        qry='''
        SELECT 
        strftime('%Y', SHIFT_DT) AS SHIFT_YEAR,
        strftime('%m', SHIFT_DT) AS SHIFT_MONTH,
        SHIFT_DT,
        FUNCTION_NM,
        EMP_COMMENTS,
        -- Combine components for TS_START
        SUBSTR(TS_START, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_START, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 15, 2)) = 1 THEN '0' || SUBSTR(TS_START, 15, 2)
            ELSE SUBSTR(TS_START, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_START, 18, 2)) = 1 THEN '0' || SUBSTR(TS_START, 18, 2)
            ELSE SUBSTR(TS_START, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_START,
        -- Combine components for TS_END
        SUBSTR(TS_END, 1, 10) || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) > 12 THEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) - 12
            ELSE CAST(SUBSTR(TS_END, 12, 2) AS INTEGER)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 15, 2)) = 1 THEN '0' || SUBSTR(TS_END, 15, 2)
            ELSE SUBSTR(TS_END, 15, 2)
        END || ':' || CASE
            WHEN LENGTH(SUBSTR(TS_END, 18, 2)) = 1 THEN '0' || SUBSTR(TS_END, 18, 2)
            ELSE SUBSTR(TS_END, 18, 2)
        END || ' ' || CASE
            WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) >= 12 THEN 'PM'
            ELSE 'AM'
        END AS TS_END,
        ROUND(
            (julianday(TS_END) - julianday(TS_START)) * 24 * 60,
            2
        ) AS MINUTE_SPENT
    FROM TBL_ACTIVITY
    WHERE EMP_SID = ?
        AND ACTIVITY_TYPE = 'NONPRODUCTION' AND SHIFT_YEAR = ? AND SHIFT_MONTH = ?
    ORDER BY ID DESC;
        ''' 
        cursor.execute(qry,(usersid,att_year,att_month))
        data = cursor.fetchall()
        return render_template('JUP1001/nonprod.html',  month_names=month_names, usersid=usersid, username=username, userprofile=userprofile,myapp=myapp,data=data)
  
    else:
        return redirect('/')   

#route.tracknonprod      
@bp_jup1001.route('/tracknprod', methods=['POST'])
def tracknprod():
    usersid = session.get('ses_empsid')
    nprod = request.form['nprod']
    comments = request.form['comments']

    if usersid:
        conn = db_conn()
        cursor = conn.cursor()

        #check if there is active shift
        cursor.execute('SELECT ID, SHIFT_DT FROM TBL_ATTENDANCE WHERE TS_LOGOUT IS NULL AND EMP_SID = ?', (usersid,))
        r = cursor.fetchone()

        if r:
            shiftid = r[0]
            shiftdt = r[1]

            cursor.execute('SELECT MAX(TS_END) FROM TBL_ACTIVITY WHERE EMP_SID = ?', (usersid,))
            ts = cursor.fetchone()
            tsstart = ts[0]

            cursor.execute('SELECT DEPARTMENT, WORKGROUP, FUNCTION_GROUP FROM TBL_USER WHERE EMP_SID = ? ', (usersid,))
            result = cursor.fetchone()
            dept =result[0]
            wgroup = result[1]
            fgroup = result[2]
            
            eastern = pytz.timezone('US/Eastern')
            tsend = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')


            #insert non prod activity to TBL_ACTIVITY
            qry = '''
            INSERT INTO TBL_ACTIVITY (EMP_SID, SHIFT_DT, TS_START, TS_END, DEPARTMENT, WORKGROUP, FUNCTION_GROUP, FUNCTION_NM, ACTIVITY_TYPE, EMP_COMMENTS)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            ''' 
            cursor.execute(qry, (usersid,shiftdt,tsstart,tsend,dept,wgroup,fgroup,nprod,'NONPRODUCTION',comments))    
            conn.commit()

            conn.close()

            flash('SUCCESS: Non production activity - ' + nprod + ' tracked.', 'success')
        
        else:
            flash('ERROR: No active shift found. Please log attendance to track activities.', 'danger')

    return redirect('/JUP1001/nonprod')

#route.production XPROD
@bp_jup1001.route('/prod')
def prod():
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')
    
    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get userprofile
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()

        #get all prod data
        qry='''
        SELECT * , d.DEPARTMENT, d.FUNCTION_GROUP, d.WORKGROUP
        FROM TBL_PIPELINE t
        JOIN TBL_DEPT d ON t.FUNCTION_NM = d.FUNCTION_NM
        WHERE SID_LOCKEDTO = ?
        ''' 
        cursor.execute(qry,(usersid,))
        data = cursor.fetchall()
        return render_template('JUP1001/prod.html', usersid=usersid, username=username, userprofile=userprofile,myapp=myapp,data=data)
  
    else:
        return redirect('/')   

#route prod action
@bp_jup1001.route('prodaction', methods=['POST'])
def prodaction():

    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')
    
    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        eastern = pytz.timezone('US/Eastern')
        gettime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')
        #get userprofile
        qry='''
            SELECT FUNCTION_GROUP FROM TBL_USER
            WHERE EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        u = cursor.fetchone()
        fgroup = u[0]
   
        #get next logic
        if request.form.get('submit_btn') == 'getnext':

            #check first if 3 loans locked to user
            cursor.execute('SELECT COUNT(ID) FROM TBL_PIPELINE WHERE SID_LOCKEDTO = ?', (usersid,))
            l = cursor.fetchone()
            locked = l[0]

            if locked >= 3:
                flash('INFORMATION: Exceeds maximum loan in queue.', 'danger')
                return redirect('/JUP1001/prod')
            else:
                qry = '''
                UPDATE TBL_PIPELINE 
                SET REVIEW_STATUS_1 = 'PENDING', SID_LOCKEDTO = ?, TS_GETTIME = ?
                WHERE ID IN (
                    SELECT p.ID
                    FROM TBL_PIPELINE p
                    JOIN TBL_DEPT d ON p.FUNCTION_NM = d.FUNCTION_NM
                    WHERE REVIEW_STATUS_1 = 'OPEN' AND FUNCTION_GROUP = ?
                    ORDER BY DT_PIPELINE ASC, TASK_PRIORITY ASC, RANDOM()
                    LIMIT 1
                );
                '''
                cursor.execute(qry,(usersid,gettime,fgroup))
                conn.commit()
                # Check if any rows were affected by the update
                if cursor.rowcount == 0:
                    # No loans available
                    flash('INFORMATION: No work available.', 'danger')
                else:
                    # Loan locked successfully
                    flash('SUCCESS: Loan selected and ready for review.', 'success')

                return redirect('/JUP1001/prod')
        
        elif request.form.get('submit_btn') == 'loansearch':
          return 'loansearch'


#route to production workspace
@bp_jup1001.route('/prodworkspace/<id>')
def prodworkspace(id):
    usersid = session.get('ses_empsid')
    username = session.get('ses_empname')
    
    if usersid:
        conn = db_conn()
        cursor = conn.cursor()
        #get userprofile
        qry='''
            SELECT u.EMP_SID, u.EMP_NAME,
            u.ACCESS_LEVEL, 
            u.DEPARTMENT,
            u.WORKGROUP,
            u.FUNCTION_GROUP,
            ul1.EMP_L1_SID, ul1.EMP_NAME as EMP_L1_NAME,
            ul2.EMP_L2_SID, ul2.EMP_NAME as EMP_L2_NAME,
            ul3.EMP_L3_SID, ul3.EMP_NAME as EMP_L3_NAME,
            ul4.EMP_L4_SID, ul4.EMP_NAME as EMP_L4_NAME,
            ul5.EMP_L5_SID, ul5.EMP_NAME as EMP_L5_NAME
            FROM TBL_USER u
            LEFT JOIN TBL_USER ul1 ON ul1.EMP_SID = u.EMP_L1_SID
            LEFT JOIN TBL_USER ul2 ON ul2.EMP_SID = u.EMP_L2_SID
            LEFT JOIN TBL_USER ul3 ON ul3.EMP_SID = u.EMP_L3_SID
            LEFT JOIN TBL_USER ul4 ON ul4.EMP_SID = u.EMP_L4_SID
            LEFT JOIN TBL_USER ul5 ON ul5.EMP_SID = u.EMP_L5_SID
            WHERE u.EMP_SID = ?
        '''
        cursor.execute(qry, (usersid,))
        userprofile = cursor.fetchall()

        #user list of access
        cursor.execute('SELECT a.APPID, l.APPNAME FROM TBL_APPACCESS a JOIN TBL_APPLIST l ON a.APPID = l.APPID WHERE a.EMP_SID = ?', (usersid,))
        myapp = cursor.fetchall()

        #get case id details
        qry = '''
            SELECT * , d.DEPARTMENT, d.FUNCTION_GROUP, d.WORKGROUP
            FROM TBL_PIPELINE t
            JOIN TBL_DEPT d ON t.FUNCTION_NM = d.FUNCTION_NM
            WHERE ID = ?
        '''
        cursor.execute(qry,(id,))
        data = cursor.fetchall()
        conn.close()
        
        return render_template('JUP1001/prodworkspace.html', usersid=usersid, username=username, userprofile=userprofile,myapp=myapp, data=data)
  
    else:
        return redirect('/')   
    
#saving review status loanlevel
@bp_jup1001.route('/saveloanreview', methods=['POST'])
def saveloanreview():
        usersid = session.get('ses_empsid')

        if usersid:
            conn = db_conn()
            cursor = conn.cursor()

            if request.method == 'POST':
                id = request.form['caseid']
                revstatus = request.form.get('revstatus')
                prevstatus = request.form['prevstatus']
                revcomments = request.form['revcomments']
                dept = request.form['dept']
                wgroup = request.form['wgroup']
                fgroup = request.form['fgroup']
                fname = request.form['fname']
                casenumber = request.form['casenumber']
                revtype = request.form['revtype']
                taskprio = request.form['taskprio']
                product = request.form['product']

                 #check if there is active shift
                cursor.execute('SELECT ID, SHIFT_DT FROM TBL_ATTENDANCE WHERE TS_LOGOUT IS NULL AND EMP_SID = ?', (usersid,))
                r = cursor.fetchone()

                if r:
                    shiftid = r[0]
                    shiftdt = r[1]

                    cursor.execute('SELECT MAX(TS_END) FROM TBL_ACTIVITY WHERE EMP_SID = ?', (usersid,))
                    ts = cursor.fetchone()
                    tsstart = ts[0]
                   
                    
                    eastern = pytz.timezone('US/Eastern')
                    tsend = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

                    #insert prod activity to TBL_ACTIVITY
                    qry = '''
                    INSERT INTO TBL_ACTIVITY (EMP_SID, SHIFT_DT, TS_START, TS_END, 
                    DEPARTMENT, WORKGROUP, FUNCTION_GROUP, FUNCTION_NM, 
                    CASENUMBER, EMP_COMMENTS, REVIEW_STATUS_1, REVIEW_TYPE, TASK_PRIORITY,
                    PRODUCT_TYPE, PREV_STATUS, ACTIVITY_TYPE)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?);
                    ''' 
                    cursor.execute(qry, (usersid,shiftdt,tsstart,tsend,dept,wgroup,fgroup,fname,casenumber,revcomments,revstatus,revtype,taskprio,product,prevstatus,'PRODUCTION'))    
                    conn.commit()

                    #update TBL_PIPE
                    if revstatus == 'PENDING':

                        qry = '''
                        UPDATE TBL_PIPELINE SET REVIEW_STATUS_1 = ?, SID_REVIEWER = ?, DT_REVIEW = ? WHERE ID = ?
                        '''
                        cursor.execute(qry,(revstatus, usersid, shiftdt, id))
                        conn.commit()
                    else:
                        qry = '''
                        UPDATE TBL_PIPELINE SET REVIEW_STATUS_1 = ?, SID_REVIEWER = ?, DT_REVIEW = ?, SID_LOCKEDTO = ? WHERE ID = ?
                        '''
                        cursor.execute(qry,(revstatus, usersid, shiftdt, None, id))
                        conn.commit()

                    conn.close()

                    return redirect('/JUP1001/prod')
        
                else:
                    flash('ERROR: No active shift found. Please log attendance to track activities.', 'danger')


            else:
                return 'Method not allowed'