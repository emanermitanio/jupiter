 SELECT 
                    tbla.ID,
                    tbla.REVIEW_TYPE,
                    tbla.PIPE_ID,
                    tbla.REVIEW_DATE AS CHECKER_DT,
                    tblc.CATEGORY,
                    tblc.CHKPT_ID, 
                    tblc.CHECKPOINT,
                    tbla.REVIEWER_SID AS CHECKER_SID,
                    tblu_rev.USERNAME AS CHECKER_NM,
                    tbla.REVIEWER_ANSWER AS CHECKER_ANS,
                    tbla.REVIEWER_COMMENTS AS CHECKER_COMMENTS,
                    tbla.REMEDIATED,
                    tblu_disp.USERNAME AS DISPUTE_NM, 
                    tblu_reso.USERNAME AS RESOLVED_NM,
                    m.REVIEW_DATE AS MAKER_DT,
                    mu.USERNAME AS MAKER_NM,
                    m.REVIEWER_ANSWER AS MAKER_ANS,
                    m.REVIEWER_COMMENTS AS MAKER_COMMENTS
                FROM 
                    TBL_AUDIT tbla
                JOIN 
                    TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
                LEFT JOIN 
                    TBL_USER tblu_disp ON tbla.DISPUTE_SID = tblu_disp.USERSID
                LEFT JOIN 
                    TBL_USER tblu_reso ON tbla.RESOLUTION_SID = tblu_reso.USERSID
                JOIN 
                    TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
                LEFT JOIN 
                    (SELECT 
                        REVIEW_DATE, REVIEWER_SID, REVIEWER_ANSWER, REVIEWER_COMMENTS, PIPE_ID, CHKPT_ID
                    FROM 
                        TBL_AUDIT 
                    WHERE 
                        REVIEW_TYPE = 'MAKER') m ON tbla.PIPE_ID = m.PIPE_ID AND tbla.CHKPT_ID = m.CHKPT_ID
                LEFT JOIN 
                    TBL_USER mu ON m.REVIEWER_SID = mu.USERSID
                WHERE 
                    tbla.REVIEW_TYPE = 'MAKER' 
                    AND tbla.PIPE_ID = 1;
