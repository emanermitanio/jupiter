from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
import sqlite3
import pytz

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

def get_db():
    conn = sqlite3.connect('cbio.db')
    conn.row_factory = sqlite3.Row 
    return conn

def get_ist_time():
    # Define IST timezone
    ist = pytz.timezone('Asia/Kolkata')
    
    # Get the current time in IST
    now_ist = datetime.now(ist)
    
    # Format the date and date with time
    dtnow = now_ist.strftime('%Y-%m-%d')
    tsnow = now_ist.strftime('%Y-%m-%d %H:%M:%S')
    
    return dtnow, tsnow

@app.route('/')
def index():
    session.clear()
    return render_template('index.html')

@app.route('/home')
def home():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    if usersid:
        # Pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = 1  # Number of items per page

        # Get total number of cases
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM TBL_PIPELINE WHERE ASSIGNED_SID = ? AND REVIEW_STATUS = 'LOCKED'", (usersid,))
        total = cursor.fetchone()[0]

        # Get assigned cases with limit and offset
        offset = (page - 1) * per_page
        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE ASSIGNED_SID = ? AND REVIEW_STATUS = 'LOCKED' LIMIT ? OFFSET ?", (usersid, per_page, offset))
        d_assigned = cursor.fetchall()
        cursor.close()
        conn.close()

        total_pages = (total + per_page - 1) // per_page  # Calculate total pages

        return render_template('home.html', usersid=usersid, username=username, useraccess=useraccess, d_assigned=d_assigned, page=page, total_pages=total_pages)
    else:
        return redirect('/')
    
@app.route('/changepassword')
def changepassword():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    if usersid:
        return render_template('changepassword.html', usersid=usersid, username=username, useraccess=useraccess)
    else:
        return redirect('/')

@app.route('/userchangepassword', methods=['POST'])   
def userchangepassword():
    usersid = session.get('sess_usersid')
    userpassword = request.form['userpassword']
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_USER SET USERPASSWORD = ? WHERE USERSID = ?", (userpassword,usersid))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect('/')


@app.route('/userlogin', methods=['POST'])
def userlogin():
    u_sid = request.form['usersid']
    u_pass = request.form['userpassword']

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT USERSID, USERNAME, ACCESS_LEVEL FROM TBL_USER WHERE USERSID = ? AND USERPASSWORD = ?", (u_sid, u_pass))
    userdata = cursor.fetchone()
    
    if userdata:
        session['sess_usersid'] = userdata[0]
        session['sess_username'] = userdata[1]
        session['sess_useraccess'] = userdata[2]
        cursor.close()
        db.close()
        return redirect(url_for('home'))
    else:
        flash('Invalid credentials. Please try again.', 'error')
        cursor.close()
        db.close()
        return redirect(url_for('index'))
    

# MANAGER PAGE
@app.route('/manager')
def manager():
   
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    if useraccess > 1:

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE REVIEW_STATUS = 'OPEN'")
        d_unassigned = cursor.fetchall()

        #get all users
        cursor.execute("SELECT USERSID, USERNAME, WORKGROUP FROM TBL_USER ORDER BY USERNAME")
        users = cursor.fetchall()

        cursor.close()
        conn.close()
        

        return render_template('manager.html', usersid=usersid, username=username,d_unassigned=d_unassigned,users=users)
    else:
        return redirect('/home')


@app.route('/assign_case', methods=['POST'])
def assign_case():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    a_sid = request.form.get('assignedsid')
    assignedsid = a_sid[:7]
    assignedname = a_sid[7:]
    pipeid = request.form['pipeid']
    priority = request.form.get('priority')
    dtnow, tsnow = get_ist_time()

    if useraccess > 1:

        conn = get_db()
        cursor = conn.cursor()


        #get all users
        cursor.execute("SELECT USERSID, USERNAME, WORKGROUP FROM TBL_USER ORDER BY USERNAME")
        users = cursor.fetchall()

        cursor.execute("UPDATE TBL_PIPELINE SET ASSIGNED_SID = ?, ASSIGNED_REVIEWER = ?, PRIORITY = ?, REVIEW_STATUS = 'LOCKED', ASSIGNED_DATE = ? WHERE PIPE_ID = ?", (assignedsid,assignedname,priority,tsnow,pipeid))
        conn.commit()       

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE REVIEW_STATUS = 'OPEN'")
        d_unassigned = cursor.fetchall()

        cursor.close()
        conn.close()

        flash('Case assignment complete.', 'success')
        

        return render_template('manager.html', usersid=usersid, username=username,d_unassigned=d_unassigned,users=users)
    else:
        return redirect('/home')
    
@app.route('/casedetails')
def casedetails():

    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    pipe_id = request.args.get('pipe_id')

    if usersid:

        #get assigned cases

        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID=?", (pipe_id,))
        casedetails = cursor.fetchall()

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID=?", (pipe_id,))
        getdetails = cursor.fetchone()

        wgroup = getdetails['WORKGROUP']
        pkgtype = getdetails['PACKAGE_TYPE']
        loc = getdetails['LOCATION']

        #check if there is available checklist

        cursor.execute("SELECT COUNT(*) FROM TBL_CHECKLIST WHERE WORKGROUP = ? AND PACKAGE_TYPE = ? AND LOCATION = ?", (wgroup,pkgtype,loc))
        chk_avail = cursor.fetchone()[0]

        #get logged checklist for this pipeid
        qry = '''
       SELECT 
    ta.PIPE_ID, 
    ta.REVIEW_TYPE, 
    ta.REVIEW_DATE, 
    ta.REVIEWER_SID, 
    tu.USERNAME AS REVIEWER_NM,
    CASE 
        WHEN COUNT(*) = 0 THEN 0
        ELSE ROUND(CAST(SUM(CASE WHEN ta.REVIEWER_ANSWER IS NOT NULL AND ta.REVIEWER_ANSWER <> '' THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*) * 100, 2)
    END AS COMPLETION_RATE
FROM TBL_AUDIT ta
JOIN TBL_USER tu ON ta.REVIEWER_SID = tu.USERSID
WHERE ta.PIPE_ID = ?
GROUP BY ta.PIPE_ID, ta.REVIEW_TYPE, ta.REVIEW_DATE, ta.REVIEWER_SID, tu.USERNAME;



        '''
        cursor.execute(qry,(pipe_id,))
        audits = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('casedetails.html', usersid=usersid, username=username, useraccess=useraccess,
                               casedetails=casedetails,chk_avail=chk_avail,audits=audits)
    else:
        return redirect('/')

@app.route('/updateworkflow', methods=['POST'])
def updateworkflow():
    pipe_id = request.form['pipe_id']
    process = request.form.get('process')
    reason = request.form.get('reason')

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET PROCESS = ?, PENDING_REJECT_REASON = ? WHERE PIPE_ID =?", (process,reason,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect('/home')

@app.route('/clonerequest', methods=['POST'])
def clonerequest():
    pipe_id = request.form['pipe_id']
    ecid = request.form['ecid']
   
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID = ?", (pipe_id,))
    record = cursor.fetchone()

    if record:
        columns = [desc[0] for desc in cursor.description if desc[0] != 'PIPE_ID']
        values = [record[i] for i in range(len(record)) if cursor.description[i][0] != 'PIPE_ID']
        
        # Update the ECID value in the list
        if 'ECID' in columns:
            ecid_index = columns.index('ECID')
            values[ecid_index] = ecid

        placeholders = ', '.join(['?'] * len(columns))
        columns = ', '.join(columns)
        cursor.execute(f"INSERT INTO TBL_PIPELINE ({columns}) VALUES ({placeholders})", values)
        conn.commit()

    cursor.close()
    conn.close()

    return redirect('/home')

@app.route('/updateEntityName', methods=['POST'])
def updateEntityName():
    pipe_id = request.form['pipe_id']
    entityname = request.form['entityname']
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET ENTITY_NAME = ? WHERE PIPE_ID =?", (entityname,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updateEntityCount', methods=['POST'])
def updateEntityCount():
    pipe_id = request.form['pipe_id']
    entitycount = request.form['entitycount']
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET NO_OF_ENTITIES = ? WHERE PIPE_ID =?", (entitycount,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updatePackageType', methods=['POST'])
def updatePackageType():
    pipe_id = request.form['pipe_id']
    packagetype = request.form.get('packagetype')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET PACKAGE_TYPE = ? WHERE PIPE_ID =?", (packagetype,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updateLocation', methods=['POST'])
def updateLocation():
    pipe_id = request.form['pipe_id']
    location = request.form.get('location')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET LOCATION = ? WHERE PIPE_ID =?", (location,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/updateECID', methods=['POST'])
def updateECID():
    pipe_id = request.form['pipe_id']
    ecid = request.form['ecid']
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE TBL_PIPELINE SET ECID = ? WHERE PIPE_ID =?", (ecid,pipe_id))
    conn.commit()
    cursor.close()
    conn.close()

    return redirect(request.referrer)

@app.route('/createreview', methods=['POST'])
def createreview():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')
    dtnow, tsnow = get_ist_time()

    pipe_id = request.form['pipe_id']
    reviewtype = request.form['reviewtype']
    wgroup = request.form['wgroup']
    packagetype = request.form['packagetype']
    location = request.form['location']

    session['sess_pipe_id'] = pipe_id

    conn = get_db()
    cursor = conn.cursor()
    qry = '''
INSERT INTO TBL_AUDIT (
    REVIEW_TYPE,
    PIPE_ID,
    CHKPT_ID,
    REVIEW_DATE,
    REVIEWER_SID
)
SELECT 
    ? AS REVIEW_TYPE,
    ? AS PIPE_ID,
    CHKPT_ID,
    ? AS REVIEW_DATE,
    ? AS REVIEWER_SID
FROM TBL_CHECKLIST
WHERE WORKGROUP = ? AND PACKAGE_TYPE = ? AND LOCATION = ? AND ACTIVE = 1;

'''
    cursor.execute(qry,(reviewtype,pipe_id,dtnow,usersid,wgroup,packagetype,location))
    conn.commit()


    return redirect('/checklist')

@app.route('/checklist')
def checklist():

    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')
    pipe_id = session.get('sess_pipe_id')
    reviewtype = request.args.get('reviewtype')
    if usersid:

        #get created checklist for this pipe_id

        conn = get_db()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE PIPE_ID=?", (pipe_id,))
        casedetails = cursor.fetchall()

        #get questions
        q = '''
            SELECT tbla.*, tblc.CATEGORY, tblc.CHECKPOINT, tblu_rev.USERNAME AS REVIEWER_NM, tblu_rev.USERNAME AS DISPUTE_NM, tblu_reso.USERNAME FROM TBL_AUDIT tbla
            JOIN TBL_USER tblu_rev ON tbla.REVIEWER_SID = tblu_rev.USERSID
            JOIN TBL_USER tblu_disp ON tbla.REVIEWER_SID = tblu_disp.USERSID
            JOIN TBL_USER tblu_reso ON tbla.REVIEWER_SID = tblu_reso.USERSID
            JOIN TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
            WHERE tbla.REVIEW_TYPE = ? AND tbla.PIPE_ID = ?
        '''
        cursor.execute(q,(reviewtype,pipe_id))
        questionset = cursor.fetchall()

        #get categories
        q = '''
        SELECT 
            tblc.CATEGORY,
            COUNT(CASE WHEN tbla.REVIEWER_ANSWER IS NULL THEN 1 END) AS PENDING
        FROM 
            TBL_AUDIT tbla
        JOIN 
            TBL_CHECKLIST tblc ON tbla.CHKPT_ID = tblc.CHKPT_ID
        WHERE 
            tbla.REVIEW_TYPE = ? 
            AND tbla.PIPE_ID = ?
        GROUP BY 
            tblc.CATEGORY
        '''
        cursor.execute(q,(reviewtype,pipe_id))
        categories = cursor.fetchall()

        cursor.close()
        conn.close()

        return render_template('checklist.html', usersid=usersid, username=username, useraccess=useraccess,
                               casedetails=casedetails,questionset=questionset,categories=categories)
    else:
        return redirect('/')

@app.route('/updateReviewerAnswer', methods=['POST'])
def updateReviewerAnswer():
    id = request.form['id']
    answer = request.form.get('dropdownOption') or request.form.get('radioOption') or request.form.get('textInput')
    
    print(answer)
    
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE TBL_AUDIT SET REVIEWER_ANSWER = ? WHERE ID = ?', (answer, id))
    conn.commit()
    conn.close()
    
    return redirect(request.referrer)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)
