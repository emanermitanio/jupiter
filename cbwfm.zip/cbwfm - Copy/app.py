from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
import sqlite3
import pytz

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

def get_db():
    conn = sqlite3.connect('cbio.db')
    conn.row_factory = sqlite3.Row 
    return conn

def get_ist_time():
    # Define IST timezone
    ist = pytz.timezone('Asia/Kolkata')
    
    # Get the current time in IST
    now_ist = datetime.now(ist)
    
    # Format the date and date with time
    dtnow = now_ist.strftime('%Y-%m-%d')
    tsnow = now_ist.strftime('%Y-%m-%d %H:%M:%S')
    
    return dtnow, tsnow

@app.route('/')
def index():
    session.clear()
    return render_template('index.html')

@app.route('/home')
def home():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    if usersid:

        #get assigned cases

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE ASSIGNED_SID = ? AND REVIEW_STATUS = 'LOCKED'", (usersid,))
        d_assigned = cursor.fetchall()
        cursor.close()
        conn.close()

        return render_template('home.html', usersid=usersid, username=username, useraccess=useraccess, d_assigned=d_assigned)
    else:
        return redirect('/')
    
@app.route('/userlogin', methods=['POST'])
def userlogin():
    u_sid = request.form['usersid']
    u_pass = request.form['userpassword']

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT USERSID, USERNAME, ACCESS_LEVEL FROM TBL_USER WHERE USERSID = ? AND USERPASSWORD = ?", (u_sid, u_pass))
    userdata = cursor.fetchone()
    
    if userdata:
        session['sess_usersid'] = userdata[0]
        session['sess_username'] = userdata[1]
        session['sess_useraccess'] = userdata[2]
        cursor.close()
        db.close()
        return redirect(url_for('home'))
    else:
        flash('Invalid credentials. Please try again.', 'error')
        cursor.close()
        db.close()
        return redirect(url_for('index'))
    

# MANAGER PAGE
@app.route('/manager')
def manager():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    if useraccess > 1:

        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE REVIEW_STATUS = 'OPEN'")
        d_unassigned = cursor.fetchall()

        #get all users
        cursor.execute("SELECT USERSID, USERNAME, WORKGROUP FROM TBL_USER ORDER BY USERNAME")
        users = cursor.fetchall()

        cursor.close()
        conn.close()
        

        return render_template('manager.html', usersid=usersid, username=username,d_unassigned=d_unassigned,users=users)
    else:
        return redirect('/home')


@app.route('/assign_case', methods=['POST'])
def assign_case():
    usersid = session.get('sess_usersid')
    username = session.get('sess_username')
    useraccess = session.get('sess_useraccess')

    a_sid = request.form.get('assignedsid')
    assignedsid = a_sid[:7]
    assignedname = a_sid[7:]
    pipeid = request.form['pipeid']
    priority = request.form.get('priority')
    dtnow, tsnow = get_ist_time()

    if useraccess > 1:

        conn = get_db()
        cursor = conn.cursor()


        #get all users
        cursor.execute("SELECT USERSID, USERNAME, WORKGROUP FROM TBL_USER ORDER BY USERNAME")
        users = cursor.fetchall()

        cursor.execute("UPDATE TBL_PIPELINE SET ASSIGNED_SID = ?, ASSIGNED_REVIEWER = ?, PRIORITY = ?, REVIEW_STATUS = 'LOCKED', ASSIGNED_DATE = ? WHERE PIPE_ID = ?", (assignedsid,assignedname,priority,tsnow,pipeid))
        conn.commit()       

        cursor.execute("SELECT * FROM TBL_PIPELINE WHERE REVIEW_STATUS = 'OPEN'")
        d_unassigned = cursor.fetchall()

        cursor.close()
        conn.close()

        flash('Case assignment complete.', 'success')
        

        return render_template('manager.html', usersid=usersid, username=username,d_unassigned=d_unassigned,users=users)
    else:
        return redirect('/home')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8080)
