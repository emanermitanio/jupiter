SELECT
    SHIFT_DT,
    TS_START,
    TS_END,
    FUNCTION_GROUP,
    ACTIVITY_TYPE,
    FUNCTION_NM,
    LOANNUMBER,
    REVIEW_STATUS_1,
    ROUND((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
         - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24 * 60, 2) AS MINUTES_SPENT,
    USER_COMMENTS
         
FROM tbl_activity
WHERE LOANNUMBER = 'TEST7' AND FUNCTION_GROUP = 'PDDR'
ORDER BY ID DESC;
