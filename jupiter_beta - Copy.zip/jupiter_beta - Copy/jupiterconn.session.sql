
    SELECT
    COUNT(WORKSETUP) AS days_present,
    WORK_SETUP
    FROM tbl_attendance
    WHERE USERSID = 'E512547'
    GROUP BY WORK_SETUP
