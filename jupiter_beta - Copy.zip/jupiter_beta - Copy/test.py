import concurrent.futures
import requests
import json
import logging
import pytz
from datetime import datetime

# Configure logging
logging.basicConfig(filename='error.log', level=logging.ERROR)

def check_existing_user(user_id):
    # Function to check if the user already exists in the database
    # Implement this function based on your database structure and connection
    # Return True if user exists, False otherwise
    return False  # Replace this with your actual implementation

def simulate_user(user_id):
    if check_existing_user(user_id):
        print(f"User {user_id} already exists. Skipping insertion.")
        return

    max_attempts = 10
    for attempt in range(1, max_attempts + 1):
        try:
            eastern = pytz.timezone('US/Eastern')
            current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %I:%M:%S %p')

            # Your existing code to simulate a user's actions
            data = {
                "usersid": user_id,
                "shift_dt": current_datetime,
                # Add more fields as needed for your tbl_activity table
            }
            headers = {"Content-Type": "application/json"}

            # Make a POST request to insert a new record into tbl_activity
            response = requests.post("http://192.168.1.15:5001/test", json=data, headers=headers)

            # Check for a successful response (HTTP status code 2xx)
            response.raise_for_status()

            # Print the response for debugging or analysis
            print(f"User {user_id} - Status Code: {response.status_code}, Response: {response.text}")

            # Break out of the loop if the request is successful
            break

        except requests.exceptions.RequestException as e:
            # Log the error
            logging.error(f"User {user_id} - Attempt {attempt} - Error: {str(e)}")
            print(f"User {user_id} - Attempt {attempt} - Error: {str(e)}")

            # Retry the request if it's not the last attempt
            if attempt < max_attempts:
                continue

            # Log a failure message if all attempts fail
            logging.error(f"User {user_id} - All attempts failed.")
            print(f"User {user_id} - All attempts failed.")

# Specify the number of concurrent users
num_users = 1000

with concurrent.futures.ThreadPoolExecutor(max_workers=num_users) as executor:
    executor.map(simulate_user, range(num_users))
