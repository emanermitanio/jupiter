from flask import Flask, redirect,  url_for, render_template, request, session, flash, get_flashed_messages
from flask import send_from_directory,send_file
import sqlite3
from datetime import datetime, timedelta
import pytz
import os
from werkzeug.utils import secure_filename

app = Flask(__name__, static_url_path='', static_folder='static')

app.secret_key = 'jupitersuperkey'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=120)
app.config['UPLOAD_PATH'] = 'static/uploads'

def get_db_connection():
    conn = sqlite3.connect('jupiter.db', check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
@app.route('/login')
def login():
    session.clear()
    return render_template('login.html')

@app.route('/userlogin', methods=['POST'])
def userlogin():
    session.clear()
    usersid = request.form['usersid']
    userpassword = request.form['userpassword']

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('SELECT USERSID, USERNAME, ACCESSLEVEL, DEPARTMENT, WORKGROUP, FUNCTION_GROUP, CURRENT_FUNCTION, USERPASSWORD FROM tbl_user WHERE USERSID=? AND USERPASSWORD=?', (usersid.upper(), userpassword))
    user = cursor.fetchone()

    if user:
        session['ses_usersid'] = user['USERSID']
        session['ses_username'] = user['USERNAME']
        session['ses_accesslevel'] = user['ACCESSLEVEL']
        session['ses_dept'] = user['DEPARTMENT']
        session['ses_workgroup'] = user['WORKGROUP']
        session['ses_functiongroup'] = user['FUNCTION_GROUP']
        session['ses_currentfunction'] = user['CURRENT_FUNCTION']
        session['ses_sortmyAttendance'] = 1
  
        return redirect(url_for('home'))
    else:
        flash('Invalid credentials. Please try again.', 'danger')
        return render_template('login.html')

@app.route('/home')
def home():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:
        conn = get_db_connection()
        cursor = conn.cursor()

        return render_template('home.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function)
    else:
        return redirect('login')



@app.route('/JUP1001/attendance')
def attendance():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:
        conn = get_db_connection()
        cursor = conn.cursor()

        #query to get attendance data
        qry = '''
              SELECT 
    tbl_a.id, 
    tbl_a.shift_dt, 
    tbl_a.ts_login, 
    tbl_a.ts_logout, 
    tbl_a.usersid, 
    tbl_u.username,
    tbl_a.work_setup, 
    (
        SELECT MAX(tbl_act.TS_END)
        FROM tbl_activity tbl_act
        WHERE tbl_act.USERSID = tbl_a.USERSID AND tbl_act.SHIFT_DT = tbl_a.SHIFT_DT
    ) as ts_lastactivity,
    ROUND((julianday(substr(tbl_a.ts_logout, 1, 10) || ' ' || substr(tbl_a.ts_logout, 12, 8)) 
        - julianday(substr(tbl_a.ts_login, 1, 10) || ' ' || substr(tbl_a.ts_login, 12, 8))) * 24, 2) as shift_hours
FROM tbl_attendance tbl_a
JOIN tbl_user tbl_u ON tbl_a.usersid = tbl_u.usersid
WHERE tbl_u.usersid = ?
ORDER BY tbl_a.shift_dt DESC;

                    '''

        cursor.execute(qry, (usersid,))
        attendance_data = cursor.fetchall()

        return render_template('JUP1001/attendance.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,attendance_data=attendance_data)

    else:
        return redirect('login')

@app.route('/JUP1001/restartday')
def restartday():
    usersid = session.get('ses_usersid')

    conn = get_db_connection()
    cursor = conn.cursor()

    #get SHIFT DATE AND LAST ACTIVITY TS
    cursor.execute('UPDATE tbl_attendance SET TS_LOGOUT = NULL WHERE ID = (SELECT MAX(ID) FROM tbl_attendance WHERE USERSID =?);', (usersid,))
    conn.commit()
    conn.close()

    return(redirect('attendance'))
   

    
@app.route('/JUP1001/filterattendance', methods=['POST'])
def filterattendance():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')
    dt_start = request.form['dt_start']
    dt_end = request.form['dt_end']
    conn = get_db_connection()
    cursor = conn.cursor()
    #query to get attendance data
    qry = '''
                SELECT 
                tbl_a.id, 
                    tbl_a.shift_dt, 
                    tbl_a.ts_login, 
                    tbl_a.ts_logout, 
                    tbl_a.usersid, 
                    tbl_u.username,
                    tbl_a.work_setup, 
                    tbl_a.ts_lastactivity,
                    ROUND((julianday(substr(ts_logout, 1, 10) || ' ' || substr(ts_logout, 12, 8)) 
                        - julianday(substr(ts_login, 1, 10) || ' ' || substr(ts_login, 12, 8))) * 24, 2) as shift_hours
                FROM tbl_attendance tbl_a
                JOIN tbl_user tbl_u ON tbl_a.usersid = tbl_u.usersid
                WHERE tbl_u.usersid =? AND tbl_a.shift_dt >= ? AND tbl_a.shift_dt <= ?
                ORDER BY shift_dt DESC
                '''

    cursor.execute(qry, (usersid,dt_start, dt_end))
    attendance_data = cursor.fetchall()

    return render_template('JUP1001/attendance.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,attendance_data=attendance_data)

@app.route('/mod_worksetup', methods=['POST'])
def mod_worksetup():
    shiftid = request.form['shiftid']
    worksetup = request.form['worksetup']

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('UPDATE tbl_attendance SET WORK_SETUP = ? WHERE ID = ?', (worksetup, shiftid))
    conn.commit()
    conn.close()

    return redirect('/JUP1001/attendance')

@app.route('/mod_endday', methods=['POST'])
def mod_endday():
    shiftid = request.form['shiftid']

    eastern = pytz.timezone('US/Eastern')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('UPDATE tbl_attendance SET TS_LOGOUT = ?, TS_LASTACTIVITY = ? WHERE ID = ?', (current_datetime, current_datetime, shiftid))
    conn.commit()   
    conn.close()

    return redirect('/JUP1001/attendance')


@app.route('/submit_shift', methods=['POST'])
def submit_shift():
    shiftdt = request.form['shiftdt']
    worksetup = request.form['worksetup']
    usersid = session.get('ses_usersid')
    worksetup = request.form['worksetup']
    dept = session.get('ses_dept') 
    workgroup = session.get('ses_workgroup') 
    functiongroup = session.get('ses_functiongroup')

    eastern = pytz.timezone('US/Eastern')
    est_dt = datetime.now(eastern).strftime('%Y-%m-%d')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    #Manila timezone
    mnl = pytz.timezone('Asia/Manila')
    mnl_dt = datetime.now(mnl).strftime('%Y-%m-%d')

    conn = get_db_connection()
    cursor = conn.cursor()
    #check first if an active shift is present. User cannot add new shift.
    cursor.execute('SELECT ID FROM tbl_attendance WHERE USERSID =? AND TS_LOGOUT IS NULL', (usersid,))
    shiftid = cursor.fetchone()
    
    if shiftid:
        flash('There is an active shift. Unable to create new shift.', 'exists')
        return redirect('/JUP1001/attendance')

    else:
    #check first if shift date is not prior to est_dt or post mnl_dt

        if shiftdt >= est_dt and shiftdt <= mnl_dt:


            # Check if the combination of shiftdt and usersid exists in the database
            cursor.execute('SELECT * FROM tbl_attendance WHERE shift_dt=? AND usersid=?', (shiftdt, usersid))
            existing_record = cursor.fetchone()

            if existing_record:
                conn.close()
                flash('Shift already exists for ' + shiftdt, 'exists')
                return redirect('/JUP1001/attendance')
            else:
                # If not, insert a new record
                # Get the current time in Eastern Time Zone

                cursor.execute('INSERT INTO tbl_attendance (SHIFT_DT, USERSID, TS_LOGIN, TS_LASTACTIVITY, WORK_SETUP) VALUES (?, ?, ?, ?, ?)', (shiftdt, usersid, current_datetime, current_datetime, worksetup))
                conn.commit()

                qry = '''
        INSERT INTO tbl_activity (USERSID, SHIFT_DT, TS_START, TS_END, DEPARTMENT, WORKGROUP, FUNCTION_GROUP, FUNCTION_NM, ACTIVITY_TYPE)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
    '''
                cursor.execute(qry, (usersid,shiftdt,current_datetime,current_datetime,dept,workgroup,functiongroup,'LOGIN','ATTENDANCE'))
                conn.commit()

                conn.close()

                flash('Shift added successfully for ' + shiftdt, 'success')

        else:
            flash('Invalid Shift date selected - ' + shiftdt, 'exists')
        
    return redirect('/JUP1001/attendance')


@app.route('/JUP1001/production')
def production():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:
        conn = get_db_connection()
        cursor = conn.cursor()

        #Query for locked queue
        cursor.execute('SELECT COUNT(*) FROM tbl_pipe WHERE SID_LOCKEDTO =?', (usersid,))
        qry_locked_ct = cursor.fetchone()[0]

        cursor.execute('SELECT DT_PIPELINE, LOANNUMBER FROM tbl_pipe WHERE SID_LOCKEDTO =? ORDER BY DT_PIPELINE ASC, TASK_PRIORITY ASC LIMIT 1', (usersid,))
        qry_locked_old = cursor.fetchall()

        qry_locked = '''
        SELECT  
        ID, DT_PIPELINE, LOANNUMBER, TASK_PRIORITY, FUNCTION_GROUP, FUNCTION_NM, PRODUCT_TYPE, REVIEW_STATUS_1
        FROM tbl_pipe
        WHERE SID_LOCKEDTO=? ORDER BY DT_PIPELINE ASC, TASK_PRIORITY ASC
        '''
        cursor.execute(qry_locked,(usersid,))
        pipe_locked = cursor.fetchall()

        return render_template('JUP1001/production.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,pipe_locked=pipe_locked,qry_locked_ct=qry_locked_ct,qry_locked_old=qry_locked_old)

    else:
        return redirect('login')

@app.route('/JUP1001/prodcontrol', methods=['GET', 'POST'])
def prodcontrol():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:
        conn = get_db_connection()
        cursor = conn.cursor()

        if request.method == 'POST':
            if request.form.get('submit_button') == 'loansearch':
                loansearch = request.form['searchloan']

                # Query for locked queue
                cursor.execute('SELECT COUNT(*) FROM tbl_pipe WHERE SID_LOCKEDTO =?', (usersid,))
                qry_locked_ct = cursor.fetchone()[0]

                cursor.execute('SELECT DT_PIPELINE, LOANNUMBER FROM tbl_pipe WHERE SID_LOCKEDTO =? ORDER BY DT_PIPELINE ASC, TASK_PRIORITY ASC LIMIT 1', (usersid,))
                qry_locked_old = cursor.fetchall()

                qry_locked = '''
                SELECT  
                ID, DT_PIPELINE, LOANNUMBER, TASK_PRIORITY, FUNCTION_GROUP, FUNCTION_NM, PRODUCT_TYPE, REVIEW_STATUS_1
                FROM tbl_pipe
                WHERE LOANNUMBER = ? ORDER BY DT_PIPELINE ASC, TASK_PRIORITY ASC
                '''
                cursor.execute(qry_locked, (loansearch,))
                pipe_locked = cursor.fetchall()

                return render_template('JUP1001/production.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function, pipe_locked=pipe_locked, qry_locked_ct=qry_locked_ct, qry_locked_old=qry_locked_old)
            elif request.form.get('submit_button') == 'refresh':
                
                # Query for locked queue
                cursor.execute('SELECT COUNT(*) FROM tbl_pipe WHERE SID_LOCKEDTO =?', (usersid,))
                qry_locked_ct = cursor.fetchone()[0]

                cursor.execute('SELECT DT_PIPELINE, LOANNUMBER FROM tbl_pipe WHERE SID_LOCKEDTO =? ORDER BY DT_PIPELINE ASC, TASK_PRIORITY ASC LIMIT 1', (usersid,))
                qry_locked_old = cursor.fetchall()

                qry_locked = '''
                SELECT  
                ID, DT_PIPELINE, LOANNUMBER, TASK_PRIORITY, FUNCTION_GROUP, FUNCTION_NM, PRODUCT_TYPE, REVIEW_STATUS_1
                FROM tbl_pipe
                WHERE SID_LOCKEDTO = ? ORDER BY DT_PIPELINE ASC, TASK_PRIORITY ASC
                '''
                cursor.execute(qry_locked, (usersid,))
                pipe_locked = cursor.fetchall()

                return render_template('JUP1001/production.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function, pipe_locked=pipe_locked, qry_locked_ct=qry_locked_ct, qry_locked_old=qry_locked_old)
          

        # Render the page for the initial GET request
        return render_template('production.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function)

    else:
        return redirect('login')


@app.route('/JUP1001/nonproduction')
def nonproduction():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:   
        conn = get_db_connection()
        cursor = conn.cursor()

        #check if there is an active shift (no logout)
        cursor.execute('SELECT TS_LASTACTIVITY FROM tbl_attendance WHERE usersid =? AND TS_LOGOUT IS NULL', (usersid,))
        last_activity = cursor.fetchone()

        qry = '''
       SELECT 
    SHIFT_DT, 
    FUNCTION_NM, 
    USER_COMMENTS,
    -- Combine components for TS_START
    SUBSTR(TS_START, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_START, 12, 2) AS INTEGER)
    END || ':' || CAST(SUBSTR(TS_START, 15, 2) AS INTEGER) || ':' || 
    CAST(SUBSTR(TS_START, 18, 2) AS INTEGER) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_START, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_START,
    -- Combine components for TS_END
    SUBSTR(TS_END, 1, 10) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) > 12 
            THEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) - 12
        ELSE 
            CAST(SUBSTR(TS_END, 12, 2) AS INTEGER)
    END || ':' || CAST(SUBSTR(TS_END, 15, 2) AS INTEGER) || ':' || 
    CAST(SUBSTR(TS_END, 18, 2) AS INTEGER) || ' ' ||
    CASE 
        WHEN CAST(SUBSTR(TS_END, 12, 2) AS INTEGER) >= 12 
            THEN 'PM'
        ELSE 
            'AM'
    END AS TS_END,
    ROUND(
        (julianday(TS_END) - julianday(TS_START)) * 24 * 60, 
        2
    ) AS minutes_spent
FROM tbl_activity
WHERE USERSID=? AND ACTIVITY_TYPE ='NONPRODUCTION'
ORDER BY TS_END DESC;

        '''
        cursor.execute(qry, (usersid,))
        data_nprod = cursor.fetchall()

        conn.close()
        return render_template('JUP1001/nonproduction.html', usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,last_activity=last_activity,data_nprod=data_nprod)

    else:
        return redirect('/login')

@app.route('/nonprod_endaction', methods=['POST'])
def nonprod_endaction():
    functionnm = request.form['nonprod']
    comments = request.form['comments']
    usersid = session.get('ses_usersid')
    dept = session.get('ses_dept') 
    workgroup = session.get('ses_workgroup') 
    functiongroup = session.get('ses_functiongroup')

    conn = get_db_connection()
    cursor = conn.cursor()

    #get SHIFT DATE AND LAST ACTIVITY TS

    qry = '''
SELECT 
    tbl_a.shift_dt, 
    tbl_act.TS_END,
    tbl_a.id  
FROM tbl_attendance tbl_a
JOIN tbl_activity tbl_act ON tbl_a.SHIFT_DT = tbl_act.SHIFT_DT AND tbl_a.USERSID = tbl_act.USERSID
WHERE tbl_act.USERSID = ?
ORDER BY tbl_act.TS_END DESC LIMIT 1
'''

    cursor.execute(qry, (usersid,))
    last_activity = cursor.fetchone()
    shiftdt = last_activity[0]
    startts = last_activity[1]
    shiftid = last_activity[2]

    eastern = pytz.timezone('US/Eastern')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    qry = '''
        INSERT INTO tbl_activity (USERSID, SHIFT_DT, TS_START, TS_END, DEPARTMENT, WORKGROUP, FUNCTION_GROUP, FUNCTION_NM, ACTIVITY_TYPE, USER_COMMENTS)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    '''

    cursor.execute(qry, (usersid,shiftdt,startts,current_datetime,dept,workgroup,functiongroup,functionnm,'NONPRODUCTION',comments))
    conn.commit()

    conn.close()

    return redirect('/JUP1001/nonproduction')

@app.route('/JUP1001/prod_workspace/<ID>')
def prod_workspace(ID):
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:

        #get loan details
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM tbl_pipe WHERE ID =?',(ID,))
        loan_details = cursor.fetchall()

        #check if there is an active shift (no logout)
        cursor.execute('SELECT TS_LASTACTIVITY FROM tbl_attendance WHERE usersid =? AND TS_LOGOUT IS NULL', (usersid,))
        last_activity = cursor.fetchone()

        cursor.execute('''SELECT * FROM tbl_wspace_doc''')
        posts = cursor.fetchall()

        return render_template('JUP1001/prodworkspace.html',posts=posts, usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,loan_details=loan_details,last_activity=last_activity)
    else:
        return redirect('/login')
    
@app.route('/JUP1001/prodaction', methods=['POST'])#xyz
def prodaction():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')
    reviewstatus1 = request.form['reviewstatus1']
    reviewstatus2 = request.form['reviewstatus2']
    recordid = request.form['recordid']
    revcomments = request.form['revcomments']
    functiongroup = request.form['functiongroup']
    loannumber = request.form['loannumber']
    pipelinedate = request.form['pipelinedate']
    reviewtype = request.form['reviewtype']
    uwsid = request.form['uwsid']

    eastern = pytz.timezone('US/Eastern')
    est_dt = datetime.now(eastern).strftime('%Y-%m-%d')
    current_datetime = datetime.now(eastern).strftime('%Y-%m-%d %H:%M:%S')

    conn = get_db_connection()
    cursor = conn.cursor()

    if request.form.get('submit_button') == 'btnsave':


        #get SHIFT DATE AND LAST ACTIVITY TS
        qry = '''
        SELECT 
            tbl_a.shift_dt, 
            tbl_act.TS_END,
            tbl_a.id  
        FROM tbl_attendance tbl_a
        JOIN tbl_activity tbl_act ON tbl_a.SHIFT_DT = tbl_act.SHIFT_DT AND tbl_a.USERSID = tbl_act.USERSID
        WHERE tbl_act.USERSID = ?
        ORDER BY tbl_act.TS_END DESC LIMIT 1
        '''

        cursor.execute(qry, (usersid,))
        last_activity = cursor.fetchone()
        shiftdt = last_activity[0]
        startts = last_activity[1]
        shiftid = last_activity[2]       

        #get last activity

        if reviewstatus1 == 'PENDING' or reviewstatus1 == 'LOCKED':
            cursor.execute('UPDATE tbl_pipe SET REVIEW_STATUS_1=?, REVIEW_STATUS_2=?, DT_REVIEW_LAST=?, SID_REVIEW_LAST=? WHERE ID =?', (reviewstatus1, reviewstatus2, current_datetime, usersid, recordid))
        else:
            cursor.execute('UPDATE tbl_pipe SET REVIEW_STATUS_1=?, REVIEW_STATUS_2=?, DT_REVIEW_LAST =?, SID_REVIEW_LAST=?, SID_LOCKEDTO=Null WHERE ID =?', (reviewstatus1, reviewstatus2, current_datetime, usersid, recordid))
            
        conn.commit()
        cursor.execute('SELECT DEPARTMENT, WORKGROUP, FUNCTION_GROUP, FUNCTION_NM, LOANNUMBER, REVIEW_TYPE, TASK_PRIORITY, PIPELINE_SOURCE, PRODUCT_TYPE, REVIEW_STATUS_1, REVIEW_STATUS_2 FROM tbl_pipe WHERE ID =?', (recordid,))
        loan_details = cursor.fetchone()

        qry = '''
        INSERT INTO tbl_activity (
        DEPARTMENT, WORKGROUP, FUNCTION_GROUP, FUNCTION_NM, LOANNUMBER, REVIEW_TYPE, TASK_PRIORITY, PIPELINE_SOURCE, PRODUCT_TYPE, REVIEW_STATUS_1, REVIEW_STATUS_2,
        USERSID,
        SHIFT_DT,
        TS_START,
        TS_END,
        ACTIVITY_TYPE,
        USER_COMMENTS
            )
            VALUES (
                ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
            );        
        '''

        cursor.execute(qry,(loan_details[0],loan_details[1],loan_details[2],loan_details[3],loan_details[4],loan_details[5],loan_details[6],loan_details[7],loan_details[8],loan_details[9],loan_details[10], usersid, shiftdt, startts,current_datetime,'PRODUCTION',revcomments))
        conn.commit()
        conn.close()
        return redirect('/JUP1001/production')
 
        qry='''
            SELECT
                SHIFT_DT,
                TS_START,
                TS_END,
                FUNCTION_GROUP,
                FUNCTION_NM,
                LOANNUMBER,
                REVIEW_STATUS_1,
                REVIEW_STATUS_2,
                tbl_r.EMP_NAME as REVIEWER_NAME,
                USER_COMMENTS
            FROM tbl_activity
            JOIN tbl_roster tbl_r ON tbl_activity.USERSID = tbl_r.EMP_SID
            WHERE FUNCTION_GROUP = ? AND LOANNUMBER = ?
            ORDER BY ID DESC;
        '''
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(qry, (function_group, loannumber))
        activity = cursor.fetchall()
        return redirect('/prodworkspace')
    
    elif request.form.get('submit_button') == 'createworkflow':
        qry = '''
        SELECT ID
        FROM tbl_checklist_data chkdata
        JOIN tbl_checklist chk ON chkdata.CHKPT_ID = chk.CHKPT_ID
        WHERE chkdata.LOANNUMBER = ? AND chkdata.DT_PIPELINE = ? AND chk.FUNCTION_GROUP = ? AND chk.REVIEW_TYPE = ?
        '''
        cursor.execute(qry,(loannumber,pipelinedate,functiongroup,reviewtype))
        record_exist = cursor.fetchall()

        if record_exist:
            flash('Workflow already exists', 'already')
            return redirect('/JUP1001/prod_workspace/'+ recordid)
        else:
            qry = '''
            INSERT INTO tbl_checklist_data (DT_PIPELINE, LOANNUMBER, AOR_SID, RESULT_INITIAL, AUDIT_DT, AUDIT_SID, CHKPT_ID, RISK_LEVEL)
            SELECT
                ? AS DT_PIPELINE,  
                ? AS LOANNUMBER, 
                ? AS AOR_SID,
                ? AS RESULT_INITIAL,
                ? AS AUDIT_DT,
                ? AS AUDIT_SID,
                CHKPT_ID,
                RISK_LEVEL
            FROM tbl_checklist
            WHERE FUNCTION_GROUP = ? AND REVIEW_TYPE = ?
            '''
            cursor.execute(qry, (pipelinedate,loannumber,uwsid,'PENDING',est_dt,usersid,functiongroup,reviewtype))
            conn.commit()

            qry='''
                SELECT chkdata.*, chk.*
                FROM tbl_checklist_data chkdata
                JOIN tbl_checklist chk ON chkdata.CHKPT_ID = chk.CHKPT_ID
                WHERE chkdata.LOANNUMBER = ? AND chkdata.DT_PIPELINE = ? AND chk.FUNCTION_GROUP = ? AND chk.REVIEW_TYPE = ?
                ORDER BY chkdata.CHKPT_ID
            '''
            cursor.execute(qry, (loannumber,pipelinedate,functiongroup,reviewtype))
            checklist = cursor.fetchall()

            qry='''
                SELECT chk.CATEGORY
                FROM tbl_checklist_data chkdata
                JOIN tbl_checklist chk ON chkdata.CHKPT_ID = chk.CHKPT_ID
                WHERE chkdata.LOANNUMBER = ? AND chkdata.DT_PIPELINE = ? AND chk.FUNCTION_GROUP = ? AND chk.REVIEW_TYPE = ?
                GROUP BY chk.CATEGORY
                ORDER BY chkdata.CHKPT_ID
                '''
            cursor.execute(qry, (loannumber,pipelinedate,functiongroup,reviewtype))
            navcategory = cursor.fetchall()
            
            flash('Workflow successfully created', 'success')
            return redirect('/JUP1001/prod_workspace/'+ recordid)

    elif request.form.get('submit_button') == 'addimg':
        return redirect('/add_post')

@app.route('/JUP1001/useractivity/<SHIFT_DT>')
def useractivity(SHIFT_DT):
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:
         
        qry='''
            SELECT
                SHIFT_DT,
                TS_START,
                TS_END,
                FUNCTION_GROUP,
                ACTIVITY_TYPE,
                FUNCTION_NM,
                LOANNUMBER,
                REVIEW_STATUS_1,
                ROUND((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                    - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24 * 60, 2) AS MINUTES_SPENT
            FROM tbl_activity
            WHERE USERSID = ? AND SHIFT_DT = ?
            ORDER BY ID DESC;
        '''
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(qry, (usersid, SHIFT_DT))
        activity = cursor.fetchall()


        qry = '''

        WITH UTILIZATION AS (

            SELECT ACTIVITY_TYPE,
            ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT
            
            FROM tbl_activity
                    WHERE USERSID = ? AND SHIFT_DT =? AND ACTIVITY_TYPE LIKE '%PRODUCTION'    
                    GROUP BY ACTIVITY_TYPE        
        )
        SELECT
                    ACTIVITY_TYPE,
                    HOUR_SPENT,
                    ROUND(100.0 * HOUR_SPENT / SUM(HOUR_SPENT) OVER (),2) AS perc
                    FROM UTILIZATION            
                    GROUP BY ACTIVITY_TYPE
            
           '''
        cursor.execute(qry,(usersid,SHIFT_DT))

        pie_chart_results = cursor.fetchall()
        pie_labels = [result[0] for result in pie_chart_results]        
        hour_spent = [result[1] for result in pie_chart_results]        
        pie_data = [result[2] for result in pie_chart_results]

        #Productivity Summary
        qry='''
            WITH PRODUCTIVITY AS (
                SELECT
                    FUNCTION_NM,
                           ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT,
                    SUM(CASE WHEN review_status_1 = 'COMPLETED' THEN 1 ELSE 0 END) AS PROD_CTR
                FROM tbl_activity
                WHERE USERSID = ? AND SHIFT_DT =? AND ACTIVITY_TYPE LIKE '%PRODUCTION'
                GROUP BY FUNCTION_NM
            )

            SELECT
                FUNCTION_NM,
                HOUR_SPENT,
                PROD_CTR,
                ROUND(PROD_CTR / (HOUR_SPENT), 2) AS UPH
            FROM PRODUCTIVITY
            GROUP BY FUNCTION_NM, HOUR_SPENT, PROD_CTR
            ORDER BY HOUR_SPENT DESC

            '''
        cursor.execute(qry,(usersid,SHIFT_DT))
        prod_chart_results = cursor.fetchall()
        prod_labels = [result[0] for result in prod_chart_results]        
        prod_hour_spent = [result[1] for result in prod_chart_results]        
        prod_uph = [result[2] for result in prod_chart_results]

        #Overall UPH Summary
        qry = '''
        WITH PRODUCTIVITY AS (
            SELECT
                FUNCTION_NM,
         ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT,
                SUM(CASE WHEN review_status_1 = 'COMPLETED' THEN 1 ELSE 0 END) AS PROD_CTR
            FROM tbl_activity
            WHERE USERSID = ? AND SHIFT_DT =? AND ACTIVITY_TYPE LIKE 'PRODUCTION'
            GROUP BY FUNCTION_NM
        )

        SELECT
            FUNCTION_NM,
            HOUR_SPENT,
            PROD_CTR,
            ROUND(PROD_CTR / (HOUR_SPENT), 2) AS UPH
        FROM PRODUCTIVITY

        UNION ALL

        SELECT
            'OVERALL' AS FUNCTION_NM,
            ROUND(SUM(HOUR_SPENT), 2) AS HOUR_SPENT,
            SUM(PROD_CTR) AS PROD_CTR,
            ROUND(SUM(PROD_CTR) / SUM(HOUR_SPENT), 2) AS UPH
        FROM PRODUCTIVITY;

        '''
        cursor.execute(qry,(usersid,SHIFT_DT))
        uph_summary = cursor.fetchall()

        return render_template('JUP1001/useractivity.html',usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,SHIFT_DT=SHIFT_DT,activity=activity, pie_labels=pie_labels, pie_data=pie_data, hour_spent=hour_spent,prod_labels=prod_labels, prod_hour_spent=prod_hour_spent, prod_uph=prod_uph,uph_summary=uph_summary)
    else:
        return redirect('/login')

@app.route('/JUP1001/loanhistory/<function_group>/<loan_number>')
def loan_history(function_group, loan_number):

    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')

    if usersid:    
        qry='''
            SELECT
                SHIFT_DT,
                TS_START,
                TS_END,
                FUNCTION_GROUP,
                FUNCTION_NM,
                LOANNUMBER,
                REVIEW_STATUS_1,
                REVIEW_STATUS_2,
                tbl_r.EMP_NAME as REVIEWER_NAME,
                USER_COMMENTS
            FROM tbl_activity
            JOIN tbl_roster tbl_r ON tbl_activity.USERSID = tbl_r.EMP_SID
            WHERE FUNCTION_GROUP = ? AND LOANNUMBER = ?
            ORDER BY ID DESC;
        '''
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(qry, (function_group, loan_number))
        activity = cursor.fetchall()
        return render_template('JUP1001/loanhistory.html',usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,activity=activity)
    else:
        return redirect('/login')

@app.route('/monthlyperfsummary', methods=['POST'] )
def monthlyperfsummary():

    eastern = pytz.timezone('US/Eastern')
    current_datetime = datetime.now(eastern)

    default_perf_year = current_datetime.strftime('%Y')
    default_perf_month = current_datetime.strftime('%B') if current_datetime else ''


    session['perf_year'] = request.form.get('perf_year', default_perf_year)
    session['perf_month'] = request.form.get('perf_month', default_perf_month)

    return redirect('/JUP1001/mydashboard')

@app.route('/JUP1001/mydashboard')
def mydashboard():
    usersid = session.get('ses_usersid')
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')
    perf_year = session.get('perf_year')
    perf_month = session.get('perf_month')


    if usersid:
         
        qry='''
SELECT
    SHIFT_DT,
    TS_START,
    TS_END,
    FUNCTION_GROUP,
    ACTIVITY_TYPE,
    FUNCTION_NM,
    LOANNUMBER,
    REVIEW_STATUS_1,
    ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT,
    SUBSTR(SHIFT_DT, 1, 4) AS SHIFT_YEAR,
    SUBSTR(SHIFT_DT, 6, 2) AS SHIFT_MONTH,
    CASE SUBSTR(SHIFT_DT, 6, 2)
        WHEN '01' THEN 'January'
        WHEN '02' THEN 'February'
        WHEN '03' THEN 'March'
        WHEN '04' THEN 'April'
        WHEN '05' THEN 'May'
        WHEN '06' THEN 'June'
        WHEN '07' THEN 'July'
        WHEN '08' THEN 'August'
        WHEN '09' THEN 'September'
        WHEN '10' THEN 'October'
        WHEN '11' THEN 'November'
        WHEN '12' THEN 'December'
    END AS FULL_MONTH
FROM tbl_activity
WHERE USERSID = ? AND SHIFT_YEAR = ? and SHIFT_MONTH = ?
ORDER BY ID DESC;

        '''
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(qry, (usersid,perf_year, perf_month))
        activity = cursor.fetchall()


        qry = '''

        WITH UTILIZATION AS (
    SELECT
        ACTIVITY_TYPE,
        SUBSTR(SHIFT_DT, 1, 4) AS SHIFT_YEAR,
        SUBSTR(SHIFT_DT, 6, 2) AS MONTH,
    CASE SUBSTR(SHIFT_DT, 6, 2)
        WHEN '01' THEN 'January'
        WHEN '02' THEN 'February'
        WHEN '03' THEN 'March'
        WHEN '04' THEN 'April'
        WHEN '05' THEN 'May'
        WHEN '06' THEN 'June'
        WHEN '07' THEN 'July'
        WHEN '08' THEN 'August'
        WHEN '09' THEN 'September'
        WHEN '10' THEN 'October'
        WHEN '11' THEN 'November'
        WHEN '12' THEN 'December'
    END AS SHIFT_MONTH,
     ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT
    FROM
        tbl_activity
    WHERE
        USERSID = ? AND SHIFT_YEAR=? AND SHIFT_MONTH=? AND ACTIVITY_TYPE LIKE '%PRODUCTION'
    GROUP BY
        ACTIVITY_TYPE, SHIFT_YEAR, SHIFT_MONTH
)
SELECT
    ACTIVITY_TYPE,
    HOUR_SPENT,
    ROUND(100.0 * HOUR_SPENT / SUM(HOUR_SPENT) OVER (), 2) AS perc,
    SHIFT_YEAR,
    SHIFT_MONTH
FROM
    UTILIZATION
GROUP BY
   ACTIVITY_TYPE, SHIFT_YEAR, SHIFT_MONTH;
   
           '''
        cursor.execute(qry,(usersid, perf_year, perf_month))

        pie_chart_results = cursor.fetchall()
        pie_labels = [result[0] for result in pie_chart_results]        
        hour_spent = [result[1] for result in pie_chart_results]        
        pie_data = [result[2] for result in pie_chart_results]

        #Productivity Summary
        qry='''
            WITH PRODUCTIVITY AS (
                SELECT
                    FUNCTION_NM,
                           ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT,
                    SUM(CASE WHEN review_status_1 = 'COMPLETED' THEN 1 ELSE 0 END) AS PROD_CTR,
SUBSTR(SHIFT_DT, 1, 4) AS SHIFT_YEAR,
        SUBSTR(SHIFT_DT, 6, 2) AS MONTH,
    CASE SUBSTR(SHIFT_DT, 6, 2)
        WHEN '01' THEN 'January'
        WHEN '02' THEN 'February'
        WHEN '03' THEN 'March'
        WHEN '04' THEN 'April'
        WHEN '05' THEN 'May'
        WHEN '06' THEN 'June'
        WHEN '07' THEN 'July'
        WHEN '08' THEN 'August'
        WHEN '09' THEN 'September'
        WHEN '10' THEN 'October'
        WHEN '11' THEN 'November'
        WHEN '12' THEN 'December'
    END AS SHIFT_MONTH
                FROM tbl_activity
                WHERE USERSID = ? AND SHIFT_YEAR =? and SHIFT_MONTH=? AND ACTIVITY_TYPE LIKE 'PRODUCTION'
                GROUP BY FUNCTION_NM, SHIFT_YEAR, SHIFT_MONTH
            )

            SELECT
                FUNCTION_NM,
                HOUR_SPENT,
                PROD_CTR,
                ROUND(PROD_CTR / (HOUR_SPENT), 2) AS UPH
            FROM PRODUCTIVITY
            GROUP BY FUNCTION_NM, HOUR_SPENT, PROD_CTR,SHIFT_YEAR, SHIFT_MONTH
            ORDER BY HOUR_SPENT DESC

            '''
        cursor.execute(qry,(usersid,perf_year,perf_month))
        prod_chart_results = cursor.fetchall()
        prod_labels = [result[0] for result in prod_chart_results]        
        prod_hour_spent = [result[1] for result in prod_chart_results]        
        prod_uph = [result[2] for result in prod_chart_results]

        #NonProductivity Summary
        qry='''
            WITH PRODUCTIVITY AS (
                SELECT
                    FUNCTION_NM,
                           ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT,
                    SUM(CASE WHEN review_status_1 = 'COMPLETED' THEN 1 ELSE 0 END) AS PROD_CTR,
SUBSTR(SHIFT_DT, 1, 4) AS SHIFT_YEAR,
        SUBSTR(SHIFT_DT, 6, 2) AS MONTH,
    CASE SUBSTR(SHIFT_DT, 6, 2)
        WHEN '01' THEN 'January'
        WHEN '02' THEN 'February'
        WHEN '03' THEN 'March'
        WHEN '04' THEN 'April'
        WHEN '05' THEN 'May'
        WHEN '06' THEN 'June'
        WHEN '07' THEN 'July'
        WHEN '08' THEN 'August'
        WHEN '09' THEN 'September'
        WHEN '10' THEN 'October'
        WHEN '11' THEN 'November'
        WHEN '12' THEN 'December'
    END AS SHIFT_MONTH
                FROM tbl_activity
                WHERE USERSID = ? AND SHIFT_YEAR =? and SHIFT_MONTH=? AND ACTIVITY_TYPE LIKE 'NONPRODUCTION'
                GROUP BY FUNCTION_NM, SHIFT_YEAR, SHIFT_MONTH
            )

            SELECT
                FUNCTION_NM,
                HOUR_SPENT,
                PROD_CTR,
                ROUND(PROD_CTR / (HOUR_SPENT), 2) AS UPH
            FROM PRODUCTIVITY
            GROUP BY FUNCTION_NM, HOUR_SPENT, PROD_CTR,SHIFT_YEAR, SHIFT_MONTH
            ORDER BY HOUR_SPENT DESC

            '''
        cursor.execute(qry,(usersid,perf_year,perf_month))
        nprod_chart_results = cursor.fetchall()
        nprod_labels = [result[0] for result in nprod_chart_results]        
        nprod_hour_spent = [result[1] for result in nprod_chart_results]        
        nprod_uph = [result[2] for result in nprod_chart_results]


        #Overall UPH Summary
        qry = '''
        WITH PRODUCTIVITY AS (
            SELECT
                FUNCTION_NM,
ROUND(SUM((julianday(substr(TS_END, 1, 10) || ' ' || substr(TS_END, 12, 8)) 
                            - julianday(substr(TS_START, 1, 10) || ' ' || substr(TS_START, 12, 8))) * 24),2) AS HOUR_SPENT,
                SUM(CASE WHEN review_status_1 = 'COMPLETED' THEN 1 ELSE 0 END) AS PROD_CTR,
                SUBSTR(SHIFT_DT, 1, 4) AS SHIFT_YEAR,
        SUBSTR(SHIFT_DT, 6, 2) AS MONTH,
    CASE SUBSTR(SHIFT_DT, 6, 2)
        WHEN '01' THEN 'January'
        WHEN '02' THEN 'February'
        WHEN '03' THEN 'March'
        WHEN '04' THEN 'April'
        WHEN '05' THEN 'May'
        WHEN '06' THEN 'June'
        WHEN '07' THEN 'July'
        WHEN '08' THEN 'August'
        WHEN '09' THEN 'September'
        WHEN '10' THEN 'October'
        WHEN '11' THEN 'November'
        WHEN '12' THEN 'December'
    END AS SHIFT_MONTH
            FROM tbl_activity
            WHERE USERSID = ? AND SHIFT_YEAR=? AND SHIFT_MONTH=? AND ACTIVITY_TYPE LIKE 'PRODUCTION'
            GROUP BY FUNCTION_NM,SHIFT_YEAR, SHIFT_MONTH
        )

        SELECT
            FUNCTION_NM,
            HOUR_SPENT,
            PROD_CTR,
            ROUND(PROD_CTR / (HOUR_SPENT), 2) AS UPH
        FROM PRODUCTIVITY

        UNION ALL

        SELECT
            'OVERALL' AS FUNCTION_NM,
            ROUND(SUM(HOUR_SPENT), 2) AS HOUR_SPENT,
            SUM(PROD_CTR) AS PROD_CTR,
            ROUND(SUM(PROD_CTR) / SUM(HOUR_SPENT), 2) AS UPH
        FROM PRODUCTIVITY;

        '''
        cursor.execute(qry,(usersid,perf_year,perf_month))
        uph_summary = cursor.fetchall()

        #Hybrid Setup
        qry='''
   SELECT
    WORK_SETUP,
    COUNT(WORK_SETUP) AS days_present,
    printf('%.0f%%', (COUNT(WORK_SETUP) * 100.0 / (SELECT COUNT(*) FROM tbl_attendance WHERE USERSID = 'E512547' AND SUBSTR(SHIFT_DT, 1, 4) = '2024' AND SUBSTR(SHIFT_DT, 6, 2) = '01'))) AS hybrid_rate,
    SUBSTR(SHIFT_DT, 1, 4) AS SHIFT_YEAR,
    SUBSTR(SHIFT_DT, 6, 2) AS MONTH,
    CASE SUBSTR(SHIFT_DT, 6, 2)
        WHEN '01' THEN 'January'
        WHEN '02' THEN 'February'
        WHEN '03' THEN 'March'  
        WHEN '04' THEN 'April'
        WHEN '05' THEN 'May'
        WHEN '06' THEN 'June'
        WHEN '07' THEN 'July'
        WHEN '08' THEN 'August'
        WHEN '09' THEN 'September'
        WHEN '10' THEN 'October'
        WHEN '11' THEN 'November'
        WHEN '12' THEN 'December'
    END AS SHIFT_MONTH
FROM tbl_attendance
WHERE USERSID = ? AND SHIFT_YEAR = ? AND SHIFT_MONTH = ?
GROUP BY WORK_SETUP, SHIFT_YEAR, SHIFT_MONTH;

        '''
        hybrid = cursor.execute(qry,(usersid,perf_year,perf_month))

     
        return render_template('JUP1001/mydashboard.html',usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function,activity=activity, pie_labels=pie_labels, pie_data=pie_data, hour_spent=hour_spent,prod_labels=prod_labels, prod_hour_spent=prod_hour_spent, prod_uph=prod_uph,uph_summary=uph_summary,nprod_labels=nprod_labels, nprod_hour_spent=nprod_hour_spent,hybrid=hybrid,perf_year=perf_year,perf_month=perf_month)
    else:
        return redirect('/login')



@app.route('/JUP1001/workflow/<FUNCTION_GROUP>/<LOANNUMBER>/<REVIEW_TYPE>/<DT_PIPELINE>')
def workflowexaminer(FUNCTION_GROUP, LOANNUMBER, REVIEW_TYPE, DT_PIPELINE):
    usersid = session.get('ses_usersid') 
    username = session.get('ses_username')
    accesslevel = session.get('ses_accesslevel')
    current_function = session.get('ses_currentfunction')
    testnav = session.get('chkptcategory') 

    

    if usersid:
        conn = get_db_connection()
        cursor = conn.cursor()
        qry='''
                SELECT chkdata.*, chk.*
                FROM tbl_checklist_data chkdata
                JOIN tbl_checklist chk ON chkdata.CHKPT_ID = chk.CHKPT_ID
                WHERE chkdata.LOANNUMBER = ? AND chkdata.DT_PIPELINE = ? AND chk.FUNCTION_GROUP = ? AND chk.REVIEW_TYPE = ?
                ORDER BY chkdata.CHKPT_ID
            '''
        cursor.execute(qry, (LOANNUMBER,DT_PIPELINE,FUNCTION_GROUP,REVIEW_TYPE))
        checklist = cursor.fetchall()

        qry='''
                SELECT chk.CATEGORY
                FROM tbl_checklist_data chkdata
                JOIN tbl_checklist chk ON chkdata.CHKPT_ID = chk.CHKPT_ID
                WHERE chkdata.LOANNUMBER = ? AND chkdata.DT_PIPELINE = ? AND chk.FUNCTION_GROUP = ? AND chk.REVIEW_TYPE = ?
                GROUP BY chk.CATEGORY
                ORDER BY chkdata.CHKPT_ID
                '''
        cursor.execute(qry, (LOANNUMBER,DT_PIPELINE,FUNCTION_GROUP,REVIEW_TYPE))
        navcategory = cursor.fetchall()
        if testnav is None:
            testnav = ''
        return render_template('JUP1001/prodchecklist.html',testnav=testnav,usersid=usersid, username=username, accesslevel=accesslevel, current_function=current_function, checklist=checklist,navcategory=navcategory)

@app.route('/saveinitialresult', methods=['POST'])
def saveinitialresult():
    recordid = request.form['recordid']
    auditorcomments = request.form['auditorcomments']
    functiongroup = request.form['functiongroup']
    loannumber = request.form['loannumber']
    pipelinedate = request.form['pipelinedate']
    reviewtype = request.form['reviewtype']
    category = request.form['category']
    session['chkptcategory'] = category
    
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.form.get('submit_button') == 'btnpass':
        initialresult = 'PASS'
    elif request.form.get('submit_button') == 'btnfail':
        initialresult = 'FAIL'
    elif request.form.get('submit_button') == 'btnNA':
        initialresult = 'NA'

    qry = '''
            UPDATE tbl_checklist_data SET RESULT_INITIAL = ?, AUDIT_COMMENTS = ? 
            WHERE ID = ?
            '''
    cursor.execute(qry, (initialresult,auditorcomments,recordid))
    conn.commit()
    conn.close()
    return redirect('/JUP1001/workflow/' + functiongroup + '/' + loannumber + '/' + reviewtype + '/' + pipelinedate)

#add post


# Function to get all posts from the database
def get_posts():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('''SELECT * FROM tbl_wspace_doc''')
    posts = c.fetchall()
    conn.close()
    return posts

@app.route('/image')
def index():
    posts = get_posts()
    return render_template('image.html', posts=posts)

@app.route('/add_post', methods=['POST'])
def add_post():
    text = request.form['text']
    image = request.files['image']
    
    if image:
        filename = image.filename
        image.save(os.path.join(app.config['UPLOAD_PATH'], filename))
        image_path = os.path.join(app.config['UPLOAD_PATH'], filename)
        filename_only = os.path.basename(image_path)
        
        conn = get_db_connection()
        c = conn.cursor()
        c.execute('''INSERT INTO tbl_wspace_doc (DOCNAME, DOCPATH) VALUES (?, ?)''', (text, filename_only))
        conn.commit()
        conn.close()

        return f'File {filename} uploaded successfully!'
    else:
        return 'No file uploaded.'
    
@app.route('/masked_image')
def masked_image():
    try:
        # Fetch the image from the actual source
        # You can replace this URL with the actual URL of your image
        actual_image_url = "http://192.168.1.20:5001/uploads/Screenshot%202024-01-21%20113900.png"
        
        # In this example, I'm using requests library to fetch the image
        import requests
        image_response = requests.get(actual_image_url)
        
        # Set appropriate content type
        image_content_type = image_response.headers['Content-Type']
        
        # Return the image data
        return send_file(image_response.raw, mimetype=image_content_type)
    except Exception as e:
        return str(e)


if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True, port=5001)